# Modo +18 (DreamForge)

## Activarlo
Variables de entorno en el servidor:
- `NSFW_ENABLED=1` — sin esto la app sigue siendo 100% SFW y el botón +18 no aparece.
- `NSFW_REFERENCE_HOSTS=x.ai` — (opcional) dominios de las imágenes generadas que se pueden editar o animar en +18. Si xAI sirve las imágenes desde otro dominio, añádelo aquí, separado por comas.

## Flujo
1. Puerta de edad con fecha de nacimiento y confirmación.
2. Botón **+18** en la barra superior → diálogo de confirmación → modo activo (guardado en el navegador).
3. En +18: chat explícito, fotos y vídeos sin la restricción de "vestido". Los medios +18 salen difuminados hasta tocarlos (se puede desactivar).

## Límites siempre activos (servidor + cliente, `src/lib/guard.ts`)
- Menores, o estética infantil o escolar en +18
- Falta de consentimiento, incesto, zoofilia, necrofilia
- Personas reales, famosas o deepfakes
- En +18 nunca se editan ni se animan fotos subidas por el usuario: solo imágenes generadas por la app
- El retrato de perfil (el que sale en Explorar) siempre es vestido

## Antes de producción (pendiente)
- La puerta de edad es autodeclarada. Para operar en España/UE hace falta verificación de edad real (proveedor externo) y revisar la normativa vigente.
- Revisar la política de uso de xAI sobre contenido sexual en la API: pueden rechazar peticiones (la app ya muestra un mensaje amable si devuelven 400/403).
- Las conversaciones solo viven en el navegador del usuario (localStorage).
