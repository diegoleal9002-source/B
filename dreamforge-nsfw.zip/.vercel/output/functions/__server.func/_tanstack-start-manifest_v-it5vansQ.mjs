//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-it5vansQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/grok/src/routes/__root.tsx",
		children: [
			"/",
			"/chats",
			"/crear",
			"/c/$id"
		],
		preloads: [
			"/assets/index-CPJ9fJ8G.js",
			"/assets/store-BbLrV_hp.js",
			"/assets/guard-CUPjWeYY.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CPJ9fJ8G.js"
		} }]
	},
	"/": {
		filePath: "/home/claude/grok/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-OVN4Q3-U.js", "/assets/roster-mDF6pKTr.js"]
	},
	"/chats": {
		filePath: "/home/claude/grok/src/routes/chats.tsx",
		children: void 0,
		preloads: ["/assets/chats-COaoIKwh.js", "/assets/roster-mDF6pKTr.js"]
	},
	"/crear": {
		filePath: "/home/claude/grok/src/routes/crear.tsx",
		children: void 0,
		preloads: ["/assets/crear-B_a39l5X.js", "/assets/roster-mDF6pKTr.js"]
	},
	"/c/$id": {
		filePath: "/home/claude/grok/src/routes/c/$id.tsx",
		children: void 0,
		preloads: ["/assets/_id-CCQ0x34r.js", "/assets/roster-mDF6pKTr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
