import { i as __toESM } from "./_runtime.mjs";
import { n as blockedReason } from "./_ssr/guard-DSiXxkgq.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { _ as ChevronLeft, d as Image, f as ImagePlus, l as Mic, n as Volume2, o as Send, r as Video } from "./_libs/lucide-react.mjs";
import { a as hearNote, c as makeSpeech, i as finishClip, l as replyChat, n as Route, o as makeClip, r as useDream, s as makePicture } from "./_ssr/router-BTJtxY-5.mjs";
import { d as resolvePerson } from "./_ssr/roster-B-w5GD5n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-CRrL7d4R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_THREAD = [];
var SUGGESTIONS = [
	"Hola",
	"¿Cómo te ves ahora?",
	"Cuéntame de tu día"
];
function ChatPage() {
	const { id } = Route.useParams();
	const customs = useDream((s) => s.customs);
	const portraits = useDream((s) => s.portraits);
	const looks = useDream((s) => s.looks);
	const person = resolvePerson(id, customs, portraits, looks);
	const thread = useDream((s) => s.threads[id] ?? EMPTY_THREAD);
	const typing = useDream((s) => s.typingFor === id);
	const persona = useDream((s) => s.persona);
	const nsfw = useDream((s) => s.nsfw);
	const used = useDream((s) => s.used);
	const seedThread = useDream((s) => s.seedThread);
	const pushUser = useDream((s) => s.pushUser);
	const pushHer = useDream((s) => s.pushHer);
	const canSpend = useDream((s) => s.canSpend);
	const setLook = useDream((s) => s.setLook);
	const setPortrait = useDream((s) => s.setPortrait);
	const resetThread = useDream((s) => s.resetThread);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [shot, setShot] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [recording, setRecording] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const recorderRef = (0, import_react.useRef)(null);
	const busy = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (person && thread.length === 0 && !typing) seedThread(person.id, person.opener);
	}, [
		person,
		thread.length,
		typing,
		seedThread
	]);
	(0, import_react.useEffect)(() => {
		const node = scroller.current;
		if (!node) return;
		node.scrollTop = node.scrollHeight;
	}, [
		thread,
		typing,
		note
	]);
	if (!person) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-full place-items-center px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-semibold",
			children: "Esa ficha no está"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-3 inline-flex text-sm text-pink",
			children: "Volver a explorar"
		})] })
	});
	const model = person;
	async function speak(text) {
		if (canSpend("voice") !== "ok") {
			setNote(canSpend("voice") === "cap" ? "Tope de audios en este navegador." : "");
			return;
		}
		const result = await makeSpeech({ data: {
			text,
			voice: model.voice,
			nsfw
		} });
		if (!result.ok) {
			setNote(result.error);
			return;
		}
		pushHer(model.id, {
			text: "Te lo digo en voz.",
			audio: result.audio
		});
	}
	async function referenceFor(src) {
		if (nsfw) return [...useDream.getState().threads[model.id] ?? []].reverse().find((message) => message.image?.startsWith("https://") && message.role === "her")?.image || (src.startsWith("https://") ? src : void 0);
		if (src.startsWith("https://")) return src;
		try {
			const blob = src.startsWith("data:") ? await (await fetch(src)).blob() : src.startsWith("/") ? await (await fetch(src)).blob() : null;
			if (!blob) return void 0;
			const bitmap = await createImageBitmap(blob);
			const scale = Math.min(1, 768 / Math.max(bitmap.width, bitmap.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(bitmap.width * scale));
			canvas.height = Math.max(1, Math.round(bitmap.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) return void 0;
			ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
			bitmap.close();
			const data = canvas.toDataURL("image/jpeg", .82);
			return data.startsWith("data:image/") && data.length < 9e5 ? data : void 0;
		} catch {
			return;
		}
	}
	async function photo(scene, adoptLook = false) {
		if (canSpend("photo") !== "ok") {
			setNote(canSpend("photo") === "cap" ? "Tope de fotos en este navegador." : "");
			return;
		}
		const reason = blockedReason(scene, nsfw);
		if (reason) {
			pushHer(model.id, { text: reason });
			return;
		}
		setNote("Generando foto…");
		try {
			const result = await makePicture({ data: {
				name: model.name,
				age: model.age,
				style: model.style,
				appearance: model.appearance,
				scene,
				referenceUrl: await referenceFor(model.image),
				nsfw
			} });
			setNote("");
			if (!result.ok) {
				pushHer(model.id, { text: result.error });
				return;
			}
			if (adoptLook && !nsfw) setPortrait(model.id, result.url);
			pushHer(model.id, {
				text: adoptLook ? "Así me ves ahora." : "Aquí va.",
				image: result.url,
				adult: nsfw || void 0
			});
		} catch {
			setNote("");
			pushHer(model.id, { text: "La foto no salió. Prueba otra vez." });
		}
	}
	async function stillFor(scene) {
		const existing = [...useDream.getState().threads[model.id] ?? []].reverse().find((message) => message.image?.startsWith("https://"))?.image || (model.image.startsWith("https://") ? model.image : "");
		if (existing) return existing;
		if (canSpend("photo") !== "ok") {
			setNote(canSpend("photo") === "cap" ? "Tope de fotos en este navegador." : "");
			return "";
		}
		const wallet = useDream.getState();
		if (!wallet.deluxe && wallet.coins < 11) {
			setNote("Hacen falta fichas para el retrato y el vídeo.");
			wallet.setUpgradeOpen(true);
			return "";
		}
		setNote("Armo un retrato y después el vídeo…");
		const still = await makePicture({ data: {
			name: model.name,
			age: model.age,
			style: model.style,
			appearance: model.appearance,
			scene: scene || "retrato de frente, luz natural, misma persona",
			referenceUrl: await referenceFor(model.image),
			nsfw
		} });
		if (!still.ok || !still.url.startsWith("https://")) {
			pushHer(model.id, {
				text: still.ok ? "El vídeo necesita una foto en línea y esta no lo es." : still.error,
				image: still.ok ? still.url : void 0
			});
			return "";
		}
		pushHer(model.id, {
			text: "Este es el retrato que voy a mover.",
			image: still.url,
			adult: nsfw || void 0
		});
		return still.url;
	}
	async function clip(scene) {
		let frame = "";
		try {
			frame = await stillFor(scene);
		} catch {
			setNote("");
			pushHer(model.id, { text: "No pude preparar el retrato del vídeo." });
			return;
		}
		if (!frame) return;
		if (canSpend("clip") !== "ok") {
			setNote(canSpend("clip") === "cap" ? "Tope de vídeos en este navegador." : "");
			return;
		}
		setNote("Generando vídeo… puede tardar un poco.");
		try {
			const started = await makeClip({ data: {
				prompt: scene || "Mira a cámara y sonríe apenas",
				imageUrl: frame,
				nsfw
			} });
			if (!started.ok) {
				setNote("");
				pushHer(model.id, { text: started.error });
				return;
			}
			let url = started.url;
			let requestId = started.pending ? started.requestId : "";
			for (let i = 0; i < 12 && !url && requestId; i += 1) {
				await new Promise((resolve) => setTimeout(resolve, 4e3));
				const polled = await finishClip({ data: { requestId } });
				if (!polled.ok) {
					setNote("");
					pushHer(model.id, { text: polled.error });
					return;
				}
				if (!polled.pending) url = polled.url;
			}
			setNote("");
			if (!url) {
				pushHer(model.id, { text: "El vídeo sigue en cola. Prueba otra vez en un momento." });
				return;
			}
			pushHer(model.id, {
				text: "Un momento en movimiento.",
				video: url,
				adult: nsfw || void 0
			});
		} catch {
			setNote("");
			pushHer(model.id, { text: "El vídeo no salió. Prueba otra vez." });
		}
	}
	async function send(text, image, audio) {
		if (busy.current || typing || recording) return;
		const clean = text.trim();
		if (!clean && !image && !audio) return;
		const reason = blockedReason(clean, nsfw);
		if (reason) {
			setNote(reason);
			return;
		}
		busy.current = true;
		if (pushUser(model.id, clean, image, audio) !== "ok") {
			busy.current = false;
			return;
		}
		setDraft("");
		setShot("");
		setNote("");
		const history = [...thread.map((message) => ({
			role: message.role,
			text: message.text
		})), {
			role: "user",
			text: clean || "Te mando esta foto.",
			image
		}];
		try {
			const result = await replyChat({ data: {
				name: model.name,
				age: model.age,
				appearance: model.appearance,
				personality: model.personality,
				place: model.place,
				persona,
				history,
				nsfw
			} });
			if (!result.ok) {
				pushHer(model.id, { text: result.error });
				return;
			}
			let spoken;
			if (audio && canSpend("voice") === "ok") {
				const voice = await makeSpeech({ data: {
					text: result.text,
					voice: model.voice
				} });
				if (voice.ok) spoken = voice.audio;
			}
			pushHer(model.id, {
				text: result.text,
				audio: spoken
			});
			const ask = clean.toLowerCase();
			if (result.look && /cambia|pelo|ropa|ojos|aspecto|look|gafas|tatuaje|estilo/.test(ask)) {
				setLook(model.id, result.look);
				await photo(result.look, true);
			} else if (result.photo && /foto|imagen|retrato|enseña|ensen|cómo te ves|como te ves|picture|selfie|desnud|sin ropa|pic/.test(ask)) await photo(result.photo);
			else if (result.video && /vídeo|video|clip|mueve|muév/.test(ask)) await clip(result.video);
			else if (!spoken && result.voice && /audio|voz|háblame|hablame|en voz/.test(ask)) await speak(result.text);
		} catch {
			pushHer(model.id, { text: "Se cortó la conexión. Prueba otra vez." });
		} finally {
			busy.current = false;
		}
	}
	async function recordNote() {
		if (recorderRef.current) {
			recorderRef.current.stop();
			return;
		}
		if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
			dictate();
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const rec = new MediaRecorder(stream);
			const chunks = [];
			rec.ondataavailable = (event) => {
				if (event.data.size) chunks.push(event.data);
			};
			rec.onstop = () => {
				stream.getTracks().forEach((track) => track.stop());
				recorderRef.current = null;
				setRecording(false);
				const blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
				if (blob.size < 800) {
					setNote("La nota quedó vacía.");
					return;
				}
				if (blob.size > 14e5) {
					setNote("Nota demasiado larga. Máximo unos 15 segundos.");
					return;
				}
				const reader = new FileReader();
				reader.onload = () => {
					if (typeof reader.result === "string") sendSpoken(reader.result);
				};
				reader.readAsDataURL(blob);
			};
			recorderRef.current = rec;
			setRecording(true);
			setNote("Grabando… pulsa otra vez para enviar.");
			rec.start();
			window.setTimeout(() => {
				if (recorderRef.current === rec && rec.state === "recording") rec.stop();
			}, 15e3);
		} catch {
			dictate();
		}
	}
	async function sendSpoken(dataUrl) {
		setNote("Transcribiendo…");
		try {
			const heard = await hearNote({ data: {
				audio: dataUrl,
				nsfw
			} });
			if (!heard.ok) {
				setNote(heard.error);
				return;
			}
			setNote("");
			await send(heard.text, void 0, dataUrl);
		} catch {
			setNote("No pude transcribir la nota.");
		}
	}
	function onFile(file) {
		if (!file || !file.type.startsWith("image/")) return;
		if (file.size > 12e5) {
			setNote("Esa foto pesa demasiado. Prueba con una más pequeña.");
			return;
		}
		const reader = new FileReader();
		reader.onload = () => {
			if (typeof reader.result === "string") setShot(reader.result);
		};
		reader.readAsDataURL(file);
	}
	function dictate() {
		const Host = window.SpeechRecognition ?? window.webkitSpeechRecognition;
		if (!Host) {
			setNote("Este navegador no dicta por voz. Escribe el mensaje.");
			return;
		}
		const rec = new Host();
		rec.lang = "es-ES";
		rec.onresult = (event) => {
			const said = event.results[0]?.[0]?.transcript ?? "";
			if (said) setDraft((current) => current ? `${current} ${said}` : said);
		};
		rec.start();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid h-full lg:grid-cols-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex min-h-0 flex-col lg:col-span-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 border-b border-line px-2 py-2 lg:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "grid size-11 place-items-center",
							"aria-label": "Volver",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: model.image,
							alt: "",
							className: "size-10 rounded-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate font-semibold",
								children: [
									model.name,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-normal text-muted",
										children: model.age
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted",
								children: model.place
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: scroller,
					className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-4 sm:px-5",
					children: [thread.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, { message }, message.id)), (typing || note) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: note || `${model.name} está escribiendo…`
					})]
				}),
				thread.length <= 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto px-3 pb-2",
					children: SUGGESTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void send(item),
						className: "h-10 shrink-0 rounded-full bg-surface-2 px-4 text-sm text-fg",
						children: item
					}, item))
				}),
				shot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-3 pb-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: shot,
						alt: "",
						className: "h-20 rounded-xl object-cover"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "border-t border-line px-3 py-3",
					onSubmit: (event) => {
						event.preventDefault();
						send(draft, shot || void 0);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex flex-wrap items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Adjuntar foto",
									onClick: () => fileRef.current?.click(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: recording ? "Parar y enviar nota" : "Nota de voz",
									onClick: () => void recordNote(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: recording ? "size-4 text-pink" : "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Pedir foto",
									onClick: () => {
										if (busy.current || typing) {
											setNote("Espera un momento.");
											return;
										}
										busy.current = true;
										photo(draft.trim() || "retrato de ahora, misma persona, luz natural").finally(() => {
											busy.current = false;
										});
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-4 text-pink" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Pedir vídeo",
									onClick: () => {
										if (busy.current || typing) {
											setNote("Espera un momento.");
											return;
										}
										busy.current = true;
										clip(draft.trim() || "un gesto suave hacia cámara").finally(() => {
											busy.current = false;
										});
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Oír el último mensaje",
									onClick: () => {
										if (busy.current) return;
										const last = [...thread].reverse().find((message) => message.role === "her" && message.text);
										if (!last) return;
										busy.current = true;
										speak(last.text).finally(() => {
											busy.current = false;
										});
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto text-xs text-muted",
									children: [
										used.photo,
										"/8 fotos · ",
										used.voice,
										"/12 voces · ",
										used.clip,
										"/2 vídeos"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "sr-only",
									htmlFor: "draft",
									children: ["Mensaje para ", model.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "draft",
									rows: 1,
									value: draft,
									onChange: (event) => setDraft(event.target.value),
									onKeyDown: (event) => {
										if (event.key === "Enter" && !event.shiftKey) {
											event.preventDefault();
											send(draft, shot || void 0);
										}
									},
									placeholder: `Escribe a ${model.name}`,
									className: "max-h-28 min-h-11 flex-1 resize-none rounded-2xl border border-line bg-surface-2 px-4 py-3 text-sm outline-none focus-visible:outline-2 focus-visible:outline-pink"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: typing || recording || !draft.trim() && !shot,
									"aria-label": "Enviar",
									className: "grid size-11 place-items-center rounded-full bg-pink text-fg disabled:opacity-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "image/*",
							className: "hidden",
							onChange: (event) => onFile(event.target.files?.[0])
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => resetThread(model.id),
								className: "h-10 text-xs text-muted",
								children: "Borrar chat"
							})
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden min-h-0 flex-col border-l border-line lg:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: model.image,
				alt: "",
				className: "h-72 w-full object-cover object-top"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-xs text-muted",
						children: "← Explorar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 text-2xl font-extrabold tracking-tight",
						children: [
							model.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-medium text-muted",
								children: model.age
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-pink",
						children: model.place
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: model.appearance
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed",
						children: model.personality
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs leading-relaxed text-muted",
						children: ["Pide una foto, graba una nota de voz o un vídeo. Si cambias pelo o ropa, el retrato se regenera y el vídeo anima esa foto. ", nsfw ? "Modo +18 activo." : "Sin contenido explícito (activa +18 arriba)."]
					})
				]
			})]
		})]
	});
}
function Bubble({ message }) {
	const mine = message.role === "user";
	const blurNsfw = useDream((s) => s.blurNsfw);
	const [shown, setShown] = (0, import_react.useState)(false);
	const hidden = Boolean(message.adult) && blurNsfw && !shown;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: mine ? "flex justify-end" : "flex justify-start",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mine ? "max-w-md rounded-2xl rounded-br-md bg-pink px-3 py-2 text-sm leading-relaxed text-fg" : "max-w-md rounded-2xl rounded-bl-md bg-surface-2 px-3 py-2 text-sm leading-relaxed text-fg",
			children: [
				(message.image || message.video) && hidden ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setShown(true),
					className: "relative mb-2 block w-full overflow-hidden rounded-xl",
					"aria-label": "Ver contenido +18",
					children: [message.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: message.image,
						alt: "",
						className: "max-h-80 w-full scale-110 object-cover blur-2xl"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-3/4 w-full bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute inset-0 grid place-items-center text-sm font-semibold",
						children: "Toca para ver · +18"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [message.image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: message.image,
					alt: "",
					className: "mb-2 max-h-80 w-full rounded-xl object-cover"
				}), message.video && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					src: message.video,
					controls: true,
					playsInline: true,
					className: "mb-2 w-full rounded-xl"
				})] }),
				message.audio && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
					src: message.audio,
					controls: true,
					className: "mb-2 w-full"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: message.text })
			]
		})
	});
}
function IconButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		title: label,
		onClick,
		className: "grid size-10 place-items-center rounded-full bg-surface-2 text-fg",
		children
	});
}
//#endregion
export { ChatPage as component };
