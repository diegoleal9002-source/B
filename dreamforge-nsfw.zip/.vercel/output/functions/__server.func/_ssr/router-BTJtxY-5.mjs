import { i as __toESM } from "../_runtime.mjs";
import { r as yearsSince } from "./guard-DSiXxkgq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useRouter, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Sparkles, c as Plus, g as Coins, h as Compass, i as TriangleAlert, m as Flame, t as X, u as MessageCircle, v as Check } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as Trigger, n as Portal, r as Root2, t as Content2 } from "../_libs/@radix-ui/react-popover+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BTJtxY-5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* +18 mode only works when the operator turns it on with NSFW_ENABLED=1 AND the
* client asks for it (age gate + opt-in). Without the env flag the app stays SFW.
*/
/** Hosts whose images we generated ourselves. Only these can be edited in +18 mode. */
var replyChat = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("308968a23a79cb8bbaad9593216bcc7b1bcb432fcfe320cafaba3c210f0b554b"));
var makePicture = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("8adb0c386acd66a17d286436d7ab6dd3bfd2ba44b44e3b77d40cdcf6137252e8"));
var makeSpeech = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("88d94da2cd38ad1fd1fad3c02ae54f64fbc18a024b4d2c99444cc88af73bfb60"));
var makeClip = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("ed03915d079664d45ce7af2a59b1595201255cdd2bd3c89a49362083b6d8208b"));
var hearNote = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("f6ddf1d17a1d284cd772af3f457050c5459aad78dc8cb91943531cb9df50c7e2"));
var finishClip = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("d1c9b99b6e5e3a261512a29b9de013d1a9737e31182e566510284d3158a5add3"));
var adultModeAvailable = createServerFn({ method: "GET" }).handler(createSsrRpc("6ce474e9b7718843979b27dc6a5419bb79044e82600c8941be04e392f49ec11e"));
var COST = {
	text: 1,
	photo: 3,
	voice: 1,
	clip: 8
};
var CAP = {
	photo: 8,
	voice: 12,
	clip: 2
};
function uid() {
	return crypto.randomUUID();
}
function slim(message) {
	const next = { ...message };
	delete next.audio;
	if (next.image?.startsWith("data:") && next.image.length > 8e4) delete next.image;
	return next;
}
var useDream = create()(persist((set, get) => ({
	adultOk: false,
	birthDate: "",
	nsfw: false,
	blurNsfw: true,
	deluxe: false,
	coins: 24,
	persona: "",
	liked: [],
	threads: {},
	typingFor: null,
	upgradeOpen: false,
	customs: [],
	portraits: {},
	looks: {},
	used: {
		photo: 0,
		voice: 0,
		clip: 0
	},
	acceptAdult: (birthDate) => set({
		adultOk: true,
		birthDate
	}),
	setNsfw: (on) => set((state) => ({ nsfw: on && state.adultOk && Boolean(state.birthDate) })),
	setBlurNsfw: (on) => set({ blurNsfw: on }),
	setPersona: (name) => set({ persona: name.slice(0, 24) }),
	toggleLike: (id) => set((state) => ({ liked: state.liked.includes(id) ? state.liked.filter((item) => item !== id) : [...state.liked, id] })),
	setUpgradeOpen: (open) => set({ upgradeOpen: open }),
	unlockDeluxe: () => set({
		deluxe: true,
		upgradeOpen: false,
		coins: 24
	}),
	seedThread: (modelId, text) => set((state) => {
		if ((state.threads[modelId] ?? []).length > 0) return state;
		return { threads: {
			...state.threads,
			[modelId]: [{
				id: `seed-${modelId}`,
				role: "her",
				text,
				at: Date.now()
			}]
		} };
	}),
	canSpend: (kind) => {
		const state = get();
		if (kind !== "text" && state.used[kind] >= CAP[kind]) return "cap";
		if (!state.deluxe && state.coins < COST[kind]) {
			set({ upgradeOpen: true });
			return "nocoins";
		}
		return "ok";
	},
	pushUser: (modelId, text, image, audio) => {
		const trimmed = text.trim().slice(0, 500);
		if (!trimmed && !image && !audio) return "empty";
		const state = get();
		if (!state.deluxe && state.coins < 1) {
			set({ upgradeOpen: true });
			return "nocoins";
		}
		const message = {
			id: uid(),
			role: "user",
			text: trimmed || "Te mando esta foto.",
			at: Date.now(),
			image,
			audio
		};
		set({
			coins: state.deluxe ? state.coins : state.coins - 1,
			typingFor: modelId,
			threads: {
				...state.threads,
				[modelId]: [...state.threads[modelId] ?? [], message]
			}
		});
		return "ok";
	},
	pushHer: (modelId, message) => set((state) => {
		const kind = message.video ? "clip" : message.image ? "photo" : message.audio ? "voice" : "text";
		const cost = COST[kind];
		const used = kind === "text" ? state.used : {
			...state.used,
			[kind]: state.used[kind] + 1
		};
		return {
			typingFor: state.typingFor === modelId ? null : state.typingFor,
			coins: state.deluxe ? state.coins : Math.max(0, state.coins - (kind === "text" ? 0 : cost)),
			used,
			threads: {
				...state.threads,
				[modelId]: [...state.threads[modelId] ?? [], {
					id: uid(),
					role: "her",
					at: Date.now(),
					...message
				}]
			}
		};
	}),
	patchLastHer: (modelId, patch) => set((state) => {
		const thread = state.threads[modelId] ?? [];
		const last = thread[thread.length - 1];
		if (!last || last.role !== "her") return state;
		const next = thread.slice(0, -1);
		next.push({
			...last,
			...patch
		});
		return { threads: {
			...state.threads,
			[modelId]: next
		} };
	}),
	setTyping: (modelId) => set({ typingFor: modelId }),
	resetThread: (modelId) => set((state) => {
		const threads = { ...state.threads };
		delete threads[modelId];
		return {
			threads,
			typingFor: state.typingFor === modelId ? null : state.typingFor
		};
	}),
	saveCustom: (person) => set((state) => ({
		customs: [person, ...state.customs.filter((item) => item.id !== person.id)],
		portraits: {
			...state.portraits,
			[person.id]: person.image
		}
	})),
	setPortrait: (id, url) => set((state) => ({ portraits: {
		...state.portraits,
		[id]: url
	} })),
	setLook: (id, look) => set((state) => ({ looks: {
		...state.looks,
		[id]: look
	} }))
}), {
	name: "dreamforge-v2",
	partialize: (state) => ({
		adultOk: state.adultOk,
		birthDate: state.birthDate,
		nsfw: state.nsfw,
		blurNsfw: state.blurNsfw,
		deluxe: state.deluxe,
		coins: state.coins,
		persona: state.persona,
		liked: state.liked,
		customs: state.customs,
		portraits: state.portraits,
		looks: state.looks,
		used: state.used,
		threads: Object.fromEntries(Object.entries(state.threads).map(([id, messages]) => [id, messages.map(slim)]))
	})
}));
var NAV = [
	{
		to: "/",
		label: "Explorar",
		icon: Compass,
		exact: true
	},
	{
		to: "/chats",
		label: "Chats",
		icon: MessageCircle,
		exact: false
	},
	{
		to: "/crear",
		label: "Crear",
		icon: Plus,
		exact: false
	}
];
function AppShell({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const finish = () => setReady(true);
		if (useDream.persist.hasHydrated()) finish();
		const unsub = useDream.persist.onFinishHydration(finish);
		const timer = window.setTimeout(finish, 2e3);
		return () => {
			unsub?.();
			window.clearTimeout(timer);
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xl font-extrabold tracking-tight",
			children: ["Dream", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-pink",
				children: "Forge"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-0 flex-1 overflow-hidden",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgeGate, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdultModeDialog, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradeDialog, {})
		]
	});
}
function isNavActive(path, item) {
	if (item.exact) return path === item.to;
	if (item.to === "/chats") return path === "/chats" || path.startsWith("/c/");
	return path === item.to || path.startsWith(`${item.to}/`);
}
function TopBar() {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const deluxe = useDream((s) => s.deluxe);
	const coins = useDream((s) => s.coins);
	const setUpgradeOpen = useDream((s) => s.setUpgradeOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "z-20 flex h-16 shrink-0 items-center gap-3 border-b border-line bg-bg/90 px-3 backdrop-blur-md sm:px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2 text-lg font-extrabold tracking-tight",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-8 place-items-center rounded-xl bg-pink text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
						className: "size-4",
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "hidden sm:inline",
					children: ["Dream", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-pink",
						children: "Forge"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "ml-4 hidden items-center gap-1 lg:flex",
				children: NAV.map((item) => {
					const active = isNavActive(path, item);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: cn("rounded-full px-4 py-2 text-sm font-medium", active ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"),
						children: item.label
					}, item.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdultToggle, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setUpgradeOpen(true),
						className: "flex items-center gap-1.5 rounded-full bg-surface-2 px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, {
							className: "size-4 text-coin",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-coin",
							children: deluxe ? "∞" : coins
						})]
					}),
					deluxe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden rounded-full border border-line px-4 py-2 text-sm font-semibold text-coin sm:inline",
						children: "Deluxe"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setUpgradeOpen(true),
						className: "rounded-full bg-pink px-3 py-2 text-sm font-semibold text-fg sm:px-4",
						children: "Deluxe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonaButton, {})
				]
			})
		]
	});
}
function PersonaButton() {
	const persona = useDream((s) => s.persona);
	const setPersona = useDream((s) => s.setPersona);
	const initial = (persona.trim() || "Tú").slice(0, 1).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root2, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: "grid size-10 place-items-center rounded-full border border-line bg-surface-2 text-sm font-semibold",
		"aria-label": "Tu nombre en el chat",
		children: initial
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Content2, {
		align: "end",
		sideOffset: 8,
		className: "z-40 w-64 rounded-2xl border border-line bg-surface p-4 shadow-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: "Cómo te llaman"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "Solo vive en este navegador."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: persona,
				onChange: (event) => setPersona(event.target.value),
				placeholder: "Tu nombre",
				className: "mt-3 w-full rounded-xl border border-line bg-bg px-3 py-2 text-sm outline-none focus-visible:outline-2 focus-visible:outline-pink"
			})
		]
	}) })] });
}
function BottomNav() {
	const path = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "grid h-16 shrink-0 grid-cols-3 border-t border-line bg-bg lg:hidden",
		children: NAV.map((item) => {
			const active = isNavActive(path, item);
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				className: cn("flex flex-col items-center justify-center gap-1 text-xs", active ? "text-pink" : "text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-5",
					"aria-hidden": "true"
				}), item.label]
			}, item.to);
		})
	});
}
function AgeGate() {
	const adultOk = useDream((s) => s.adultOk);
	const birthDate = useDream((s) => s.birthDate);
	const acceptAdult = useDream((s) => s.acceptAdult);
	const [birth, setBirth] = (0, import_react.useState)("");
	const [checked, setChecked] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	if (adultOk && birthDate) return null;
	function enter() {
		const years = yearsSince(birth);
		if (!birth || years < 18 || years > 110) {
			setError("Tienes que ser mayor de 18 años para entrar.");
			return;
		}
		acceptAdult(birth);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-ink px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-pink uppercase",
					children: "Solo adultos"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-4xl font-extrabold tracking-tight",
					children: "Mayores de 18"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-base leading-relaxed text-muted",
					children: "DreamForge es un chat de compañía con personajes ficticios adultos. Puede incluir contenido sexual explícito si activas el modo +18. Todos los personajes son mayores de edad e inventados."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-6 block text-xs font-semibold tracking-wide text-muted uppercase",
					children: ["Fecha de nacimiento", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: birth,
						max: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
						onChange: (event) => {
							setBirth(event.target.value);
							setError("");
						},
						className: "mt-2 h-11 w-full rounded-2xl border border-line bg-surface px-4 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked,
						onChange: (event) => setChecked(event.target.checked)
					}), "Confirmo que soy mayor de edad en mi país y acepto ver contenido para adultos"]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-pink",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !checked || !birth,
					onClick: enter,
					className: "mt-4 h-12 w-full rounded-full bg-pink text-sm font-semibold text-fg disabled:opacity-40",
					children: "Entrar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://www.google.com",
					className: "mt-3 block text-center text-sm text-muted underline",
					children: "Salir"
				})
			]
		})
	});
}
function useAdultAvailable() {
	const [available, setAvailable] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		adultModeAvailable().then((r) => live && setAvailable(r.available)).catch(() => live && setAvailable(false));
		return () => {
			live = false;
		};
	}, []);
	return available;
}
var openAdultDialog = null;
function AdultToggle() {
	const nsfw = useDream((s) => s.nsfw);
	const setNsfw = useDream((s) => s.setNsfw);
	const available = useAdultAvailable();
	(0, import_react.useEffect)(() => {
		if (available === false && nsfw) setNsfw(false);
	}, [
		available,
		nsfw,
		setNsfw
	]);
	if (!available) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": nsfw,
		onClick: () => nsfw ? setNsfw(false) : openAdultDialog?.(),
		className: cn("flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-semibold", nsfw ? "bg-pink text-fg" : "bg-surface-2 text-muted"),
		title: nsfw ? "Modo +18 activo. Pulsa para desactivar." : "Activar modo +18",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
			className: "size-4",
			"aria-hidden": "true"
		}), "+18"]
	});
}
function AdultModeDialog() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const setNsfw = useDream((s) => s.setNsfw);
	const blurNsfw = useDream((s) => s.blurNsfw);
	const setBlurNsfw = useDream((s) => s.setBlurNsfw);
	(0, import_react.useEffect)(() => {
		openAdultDialog = () => setOpen(true);
		return () => {
			openAdultDialog = null;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-3xl border border-line bg-surface p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "text-2xl font-extrabold tracking-tight",
					children: "Activar modo +18"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "Los personajes podrán tener conversaciones, fotos y vídeos sexuales explícitos contigo."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						"Todos los personajes son adultos y ficticios",
						"Nada con menores, sin consentimiento, incesto o animales",
						"Nada sobre personas reales ni a partir de fotos tuyas o de otros"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "mt-0.5 size-4 shrink-0 text-pink",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
					}, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: blurNsfw,
						onChange: (e) => setBlurNsfw(e.target.checked)
					}), "Difuminar fotos y vídeos +18 hasta que los toque"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "h-12 flex-1 rounded-full bg-surface-2 text-sm font-semibold",
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setNsfw(true);
							setOpen(false);
						},
						className: "h-12 flex-1 rounded-full bg-pink text-sm font-semibold text-fg",
						children: "Activar"
					})]
				})
			]
		})] })
	});
}
function UpgradeDialog() {
	const open = useDream((s) => s.upgradeOpen);
	const setUpgradeOpen = useDream((s) => s.setUpgradeOpen);
	const deluxe = useDream((s) => s.deluxe);
	const unlockDeluxe = useDream((s) => s.unlockDeluxe);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: setUpgradeOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-3xl border border-line bg-surface p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-2xl font-extrabold tracking-tight",
						children: "Pasa a Deluxe"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "Demo local. No hay cobro ni cuenta. Solo quita el límite de fichas en este navegador."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "grid size-10 place-items-center rounded-full bg-surface-2",
						"aria-label": "Cerrar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-3 text-sm",
					children: [
						"Chat sin gastar fichas",
						"Las ocho fichas, con el mismo retrato fijo",
						"Tu nombre y las conversaciones se quedan aquí"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "mt-0.5 size-4 shrink-0 text-pink",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
					}, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: unlockDeluxe,
					disabled: deluxe,
					className: "mt-6 h-12 w-full rounded-full bg-pink text-sm font-semibold text-fg disabled:opacity-50",
					children: deluxe ? "Deluxe activo" : "Activar Deluxe"
				})
			]
		})] })
	});
}
var styles_default = "/assets/styles-D006-goP.css";
var Route$4 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "DreamForge" },
			{
				name: "description",
				content: "Chat de compañía con personajes ficticios adultos. Solo mayores de 18. Modo +18 opcional."
			},
			{
				name: "theme-color",
				content: "#07070b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "es",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$3 = () => import("./routes-BAQ8KX5J.mjs");
var Route$3 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Explorar · DreamForge" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./chats-DZ2yFC20.mjs");
var Route$2 = createFileRoute("/chats")({
	head: () => ({ meta: [{ title: "Chats · DreamForge" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./crear-ARnCDf-e.mjs");
var Route$1 = createFileRoute("/crear")({
	head: () => ({ meta: [{ title: "Crear · DreamForge" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_id-CRrL7d4R.mjs");
var Route = createFileRoute("/c/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$3.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	ChatsRoute: Route$2.update({
		id: "/chats",
		path: "/chats",
		getParentRoute: () => Route$4
	}),
	CrearRoute: Route$1.update({
		id: "/crear",
		path: "/crear",
		getParentRoute: () => Route$4
	}),
	CIdRoute: Route.update({
		id: "/c/$id",
		path: "/c/$id",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { hearNote as a, makeSpeech as c, finishClip as i, replyChat as l, Route as n, makeClip as o, useDream as r, makePicture as s, router_exports as t, cn as u };
