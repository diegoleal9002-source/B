//#region node_modules/.nitro/vite/services/ssr/assets/guard-DSiXxkgq.js
var SEXUAL = /\b(nsfw|nude|nudes|naked|sex|sexual|porn|porno|xxx|explicit|explícit\w*|lingerie|underwear|desnuda|desnudo|desnudas|desnud\w*|sexo|teta|tetas|polla|coño|cono|foll\w*|orgasmo|erotic\w*|erótic\w*|hentai|onlyfans|topless|nipple|genital\w*|sin ropa|en cueros)\b/i;
var MINOR = /\b(menor de edad|menores|niña|niño|niñas|niños|nena|nene|crí[ao]|child|children|kid|kids|loli|lolita|shota|underage|preteen|teen|teens|adolescente\w*|pubert\w*|aparenta\w* menos|cuerpo de niñ\w*|young[- ]looking|edad\s*1[0-7]|[1-9]\s*años|[1-9]\s*anos|1[0-7]\s*años|1[0-7]\s*anos|1[0-7]\s*years?)\b/i;
var YOUTH_FRAMING = /\b(schoolgirl|school ?uniform|colegiala|escolar|uniforme escolar|instituto|secundaria|bachillerato|virgen de 1\d|petite young)\b/i;
var NON_CONSENT = /\b(violaci[oó]n|violar\w*|rape\w*|non[- ]?consent\w*|sin consentimiento|forzad[ao]\w*|a la fuerza|drogad[ao]|inconsciente|unconscious|incest\w*|incesto|zoofilia|bestialit\w*|necrofilia|snuff)\b/i;
var REAL_PERSON = /\b(deepfake\w*|celebrity|celebridad|famos[ao] real|persona real|real person|mi ex|mi novia real|mi compañera de trabajo|mi vecina|mi jefa|mi profesora)\b/i;
function blockedReason(text, nsfw = false) {
	if (MINOR.test(text)) return "Solo personas adultas, de 18 años o más.";
	if (nsfw && YOUTH_FRAMING.test(text)) return "Solo personas adultas, sin estética escolar ni infantil.";
	if (NON_CONSENT.test(text)) return "Eso no entra: todo tiene que ser entre adultos y con consentimiento.";
	if (REAL_PERSON.test(text)) return "No se crean escenas sobre personas reales.";
	if (!nsfw && SEXUAL.test(text)) return "Eso no entra en modo normal. Activa el modo +18 para contenido adulto.";
	return null;
}
function adultAge(age) {
	return Number.isFinite(age) && age >= 18 && age <= 80;
}
function yearsSince(birth, now = /* @__PURE__ */ new Date()) {
	const date = new Date(birth);
	if (Number.isNaN(date.getTime())) return 0;
	let years = now.getFullYear() - date.getFullYear();
	const m = now.getMonth() - date.getMonth();
	if (m < 0 || m === 0 && now.getDate() < date.getDate()) years -= 1;
	return years;
}
//#endregion
export { blockedReason as n, yearsSince as r, adultAge as t };
