import { i as __toESM } from "../_runtime.mjs";
import { n as blockedReason, t as adultAge } from "./guard-DSiXxkgq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as useDream, s as makePicture, u as cn } from "./router-BTJtxY-5.mjs";
import { a as PRESENCE, c as SILHOUETTE_LABEL, i as HAIR, l as VOICES, n as CAST, o as PRESENCE_LABEL, r as EYES, s as SILHOUETTE, t as AGES } from "./roster-B-w5GD5n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/crear-ARnCDf-e.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_PICK = {
	hair: "rubio",
	eyes: "claros",
	presence: "marcado",
	silhouette: "marcada",
	age: 32
};
var MAX_SCORE = 10;
function likeness(model, pick) {
	let score = 0;
	const hits = [];
	if (model.hair === pick.hair) {
		score += 3;
		hits.push("pelo");
	}
	if (model.eyes === pick.eyes) {
		score += 2;
		hits.push("ojos");
	}
	if (model.presence === pick.presence) {
		score += 2;
		hits.push("presencia");
	}
	if (model.silhouette === pick.silhouette) {
		score += 1;
		hits.push("silueta");
	}
	if (model.age === pick.age) {
		score += 2;
		hits.push("edad");
	}
	return {
		score,
		hits,
		max: MAX_SCORE
	};
}
function rankModels(pick) {
	return [...CAST].sort((a, b) => {
		const delta = likeness(b, pick).score - likeness(a, pick).score;
		if (delta !== 0) return delta;
		return b.chats - a.chats;
	});
}
var STYLES = [
	{
		id: "realista",
		label: "Realista",
		note: "Foto"
	},
	{
		id: "anime",
		label: "Anime",
		note: "Dibujo"
	},
	{
		id: "ilustracion",
		label: "Ilustración",
		note: "Pintura"
	}
];
function CreatePage() {
	const navigate = useNavigate();
	const saveCustom = useDream((s) => s.saveCustom);
	const nsfw = useDream((s) => s.nsfw);
	const [name, setName] = (0, import_react.useState)("");
	const [age, setAge] = (0, import_react.useState)(27);
	const [style, setStyle] = (0, import_react.useState)("realista");
	const [appearance, setAppearance] = (0, import_react.useState)("");
	const [personality, setPersonality] = (0, import_react.useState)("");
	const [place, setPlace] = (0, import_react.useState)("");
	const [voice, setVoice] = (0, import_react.useState)("eve");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [preview, setPreview] = (0, import_react.useState)("");
	async function generate() {
		const cleanName = name.trim().slice(0, 32);
		const look = appearance.trim();
		const reason = blockedReason(`${cleanName} ${look} ${place}`) || blockedReason(personality, nsfw);
		if (!cleanName || look.length < 8) {
			setError("Pon un nombre y describe el aspecto con un poco más de detalle.");
			return;
		}
		if (!adultAge(age)) {
			setError("La edad tiene que estar entre 18 y 80.");
			return;
		}
		if (reason) {
			setError(reason);
			return;
		}
		setBusy(true);
		setError("");
		const result = await makePicture({ data: {
			name: cleanName,
			age,
			style,
			appearance: look,
			scene: place.trim() || "retrato de frente, luz suave"
		} });
		setBusy(false);
		if (!result.ok) {
			setError(result.error);
			return;
		}
		const id = `u-${crypto.randomUUID().slice(0, 8)}`;
		saveCustom({
			id,
			name: cleanName,
			age,
			style,
			appearance: look,
			personality: personality.trim() || "Cercana, con humor y sin rodeos.",
			place: place.trim() || "Aquí",
			voice,
			image: result.url,
			opener: `Hola. Soy ${cleanName}. ${personality.trim() || "Cuéntame qué te trae."}`
		});
		setPreview(result.url);
		await navigate({
			to: "/c/$id",
			params: { id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-full overflow-y-auto",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-6 px-3 py-4 sm:px-5 lg:grid-cols-[1fr_320px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-extrabold tracking-tight",
					children: "Crear desde cero"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm leading-relaxed text-muted",
					children: "No estás atado a las fichas de la casa. Describes a la persona y la IA genera el retrato. En el chat puede cambiar de aspecto si se lo pides."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-5 block text-xs font-semibold tracking-wide text-muted uppercase",
					children: ["Nombre", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (event) => setName(event.target.value),
						className: "mt-2 h-11 w-full rounded-2xl border border-line bg-surface px-4 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink",
						placeholder: "Cómo se llama"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-xs font-semibold tracking-wide text-muted uppercase",
					children: ["Edad", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 18,
						max: 80,
						value: age,
						onChange: (event) => setAge(Number(event.target.value)),
						className: "mt-2 h-11 w-28 rounded-2xl border border-line bg-surface px-4 text-sm font-normal text-fg outline-none focus-visible:outline-2 focus-visible:outline-pink"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-xs font-semibold tracking-wide text-muted uppercase",
						children: "Estilo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: STYLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": style === item.id,
							onClick: () => setStyle(item.id),
							className: cn("h-10 rounded-full px-4 text-sm", style === item.id ? "bg-pink font-semibold text-fg" : "bg-surface-2 text-muted"),
							children: item.label
						}, item.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-xs font-semibold tracking-wide text-muted uppercase",
					children: ["Aspecto", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: appearance,
						onChange: (event) => setAppearance(event.target.value),
						rows: 3,
						placeholder: "Pelo, ropa, cara, energía. Siempre adulto. (El retrato de perfil es vestido; lo +18 va en el chat.)",
						className: "mt-2 w-full resize-none rounded-2xl border border-line bg-surface px-4 py-3 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-xs font-semibold tracking-wide text-muted uppercase",
					children: ["Personalidad", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: personality,
						onChange: (event) => setPersonality(event.target.value),
						rows: 2,
						placeholder: "Cómo habla y qué le importa",
						className: "mt-2 w-full resize-none rounded-2xl border border-line bg-surface px-4 py-3 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-xs font-semibold tracking-wide text-muted uppercase",
					children: ["Dónde está", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: place,
						onChange: (event) => setPlace(event.target.value),
						className: "mt-2 h-11 w-full rounded-2xl border border-line bg-surface px-4 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink",
						placeholder: "Un café, un estudio, la calle de noche"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-xs font-semibold tracking-wide text-muted uppercase",
						children: "Voz"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: VOICES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": voice === item.id,
							onClick: () => setVoice(item.id),
							className: cn("h-10 rounded-full px-4 text-sm", voice === item.id ? "bg-pink font-semibold text-fg" : "bg-surface-2 text-muted"),
							children: item.label
						}, item.id))
					})]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-pink",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void generate(),
					className: "mt-5 h-12 w-full rounded-full bg-pink text-sm font-semibold text-fg disabled:opacity-40 sm:w-auto sm:px-8",
					children: busy ? "Generando retrato…" : "Generar y empezar a hablar"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "overflow-hidden rounded-3xl border border-line bg-surface lg:sticky lg:top-4 lg:self-start",
				children: preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: preview,
					alt: "",
					className: "aspect-3/4 w-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid aspect-3/4 place-items-center px-6 text-center text-sm text-muted",
					children: "El retrato aparece aquí cuando la IA lo termina."
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matcher, {})]
	});
}
function Matcher() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [pick, setPick] = (0, import_react.useState)(DEFAULT_PICK);
	const best = (0, import_react.useMemo)(() => rankModels(pick), [pick])[0];
	const match = best ? likeness(best, pick) : null;
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-3 pb-8 sm:px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setOpen(true),
			className: "text-sm text-muted underline",
			children: "O acercar una ficha que ya existe"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-3 pb-10 sm:px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "Fichas de la casa"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trait, {
				label: "Pelo",
				options: HAIR,
				value: pick.hair,
				onChange: (hair) => setPick((c) => ({
					...c,
					hair
				})),
				render: capitalize
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trait, {
				label: "Ojos",
				options: EYES,
				value: pick.eyes,
				onChange: (eyes) => setPick((c) => ({
					...c,
					eyes
				})),
				render: capitalize
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trait, {
				label: "Presencia",
				options: PRESENCE,
				value: pick.presence,
				onChange: (presence) => setPick((c) => ({
					...c,
					presence
				})),
				render: (value) => PRESENCE_LABEL[value]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trait, {
				label: "Silueta",
				options: SILHOUETTE,
				value: pick.silhouette,
				onChange: (silhouette) => setPick((c) => ({
					...c,
					silhouette
				})),
				render: (value) => SILHOUETTE_LABEL[value]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trait, {
				label: "Edad",
				options: AGES,
				value: pick.age,
				onChange: (age) => setPick((c) => ({
					...c,
					age
				})),
				render: (value) => String(value)
			}),
			best && match && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/c/$id",
				params: { id: best.id },
				className: "mt-4 flex items-center gap-3 rounded-2xl border border-line bg-surface p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: best.image,
					alt: "",
					className: "size-16 rounded-xl object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block font-semibold",
					children: [
						best.name,
						", ",
						best.age
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm text-muted",
					children: [
						match.score,
						" de ",
						match.max,
						match.hits.length ? ` · ${match.hits.join(", ")}` : ""
					]
				})] })]
			})
		]
	});
}
function Trait({ label, options, value, onChange, render }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
			className: "text-xs font-semibold tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex flex-wrap gap-2",
			children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": option === value,
				onClick: () => onChange(option),
				className: cn("h-10 rounded-full px-4 text-sm", option === value ? "bg-pink font-semibold text-fg" : "bg-surface-2 text-muted"),
				children: render(option)
			}, String(option)))
		})]
	});
}
function capitalize(value) {
	return value.charAt(0).toUpperCase() + value.slice(1);
}
//#endregion
export { CreatePage as component };
