import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as useDream } from "./router-BTJtxY-5.mjs";
import { f as roster } from "./roster-B-w5GD5n.mjs";
import { n as formatDistanceToNow, t as es } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chats-DZ2yFC20.js
var import_jsx_runtime = require_jsx_runtime();
function ChatsPage() {
	const threads = useDream((s) => s.threads);
	const customs = useDream((s) => s.customs);
	const portraits = useDream((s) => s.portraits);
	const looks = useDream((s) => s.looks);
	const resetThread = useDream((s) => s.resetThread);
	const people = roster(customs, portraits, looks);
	const rows = Object.entries(threads).map(([id, messages]) => {
		const model = people.find((item) => item.id === id);
		const last = messages[messages.length - 1];
		if (!model || !last) return null;
		return {
			model,
			last,
			count: messages.length
		};
	}).filter((row) => row !== null).sort((a, b) => b.last.at - a.last.at);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl px-3 py-4 sm:px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-extrabold tracking-tight",
					children: "Chats"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Las conversaciones se quedan en este navegador."
				}),
				rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 rounded-3xl border border-line bg-surface p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Todavía no hablaste con nadie."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid grid-cols-4 gap-2",
							children: people.slice(0, 4).map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/c/$id",
								params: { id: model.id },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: model.image,
									alt: model.name,
									className: "aspect-3/4 w-full rounded-xl object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 truncate text-xs",
									children: model.name
								})]
							}, model.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "mt-5 flex h-11 items-center justify-center rounded-full bg-pink text-sm font-semibold text-fg",
							children: "Explorar fichas"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-line overflow-hidden rounded-3xl border border-line bg-surface",
					children: rows.map(({ model, last }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/c/$id",
							params: { id: model.id },
							className: "flex min-w-0 flex-1 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: model.image,
								alt: "",
								className: "size-14 shrink-0 rounded-2xl object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block font-semibold",
										children: [
											model.name,
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-normal text-muted",
												children: model.age
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block truncate text-sm text-muted",
										children: last.text
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-xs text-muted",
										children: formatDistanceToNow(last.at, {
											addSuffix: true,
											locale: es
										})
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => resetThread(model.id),
							className: "shrink-0 rounded-full px-3 py-2 text-xs text-muted hover:text-fg",
							children: "Borrar"
						})]
					}, model.id))
				})
			]
		})
	});
}
//#endregion
export { ChatsPage as component };
