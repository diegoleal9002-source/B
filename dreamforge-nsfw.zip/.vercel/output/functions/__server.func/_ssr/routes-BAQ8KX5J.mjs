import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { p as Heart, s as Search } from "../_libs/lucide-react.mjs";
import { r as useDream, u as cn } from "./router-BTJtxY-5.mjs";
import { f as roster, u as formatCount } from "./roster-B-w5GD5n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BAQ8KX5J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PortraitCard({ model }) {
	const liked = useDream((s) => s.liked.includes(model.id));
	const toggleLike = useDream((s) => s.toggleLike);
	const likes = model.likes + (liked ? 1 : 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group relative overflow-hidden rounded-2xl bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/c/$id",
			params: { id: model.id },
			className: "block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: model.image,
					alt: `${model.name}, ${model.age}`,
					className: "aspect-3/4 w-full object-cover transition duration-300 group-hover:scale-105"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-ink/15 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-2.5 left-2.5 rounded-full bg-ink/70 px-2.5 py-1 text-xs font-medium text-fg",
					children: model.badge
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-semibold tracking-tight",
								children: model.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-fg/75",
								children: model.age
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 line-clamp-2 text-xs leading-snug text-fg/80",
							children: model.hook
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-fg/60",
							children: [formatCount(model.chats), " chats"]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-pressed": liked,
			"aria-label": liked ? `Quitar me gusta a ${model.name}` : `Guardar a ${model.name}`,
			onClick: () => toggleLike(model.id),
			className: "absolute top-2 right-2 grid size-10 place-items-center rounded-full bg-ink/70",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", liked ? "fill-pink text-pink" : "text-fg") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: formatCount(likes)
			})]
		})]
	});
}
var CHIPS = [
	{
		id: "todas",
		label: "Todas"
	},
	{
		id: "tendencia",
		label: "Tendencia"
	},
	{
		id: "mias",
		label: "Mías"
	},
	{
		id: "nocturna",
		label: "Nocturnas"
	},
	{
		id: "calida",
		label: "Cálidas"
	},
	{
		id: "directa",
		label: "Directas"
	},
	{
		id: "ciudad",
		label: "Ciudad"
	},
	{
		id: "estudio",
		label: "Estudio"
	},
	{
		id: "guardadas",
		label: "Guardadas"
	}
];
var BADGE = {
	realista: "Realista",
	anime: "Anime",
	ilustracion: "Dibujo"
};
function Explore() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [chip, setChip] = (0, import_react.useState)("tendencia");
	const liked = useDream((s) => s.liked);
	const customs = useDream((s) => s.customs);
	const portraits = useDream((s) => s.portraits);
	const looks = useDream((s) => s.looks);
	const setUpgradeOpen = useDream((s) => s.setUpgradeOpen);
	const deluxe = useDream((s) => s.deluxe);
	const list = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		let rows = roster(customs, portraits, looks).filter((model) => {
			if (chip === "guardadas" && !liked.includes(model.id)) return false;
			if (chip === "mias" && !model.custom) return false;
			if (chip !== "todas" && chip !== "tendencia" && chip !== "guardadas" && chip !== "mias" && !model.tags.includes(chip)) return false;
			if (!q) return true;
			return `${model.name} ${model.hook} ${model.place} ${model.appearance} ${model.tags.join(" ")}`.toLowerCase().includes(q);
		});
		if (chip === "tendencia") rows = [...rows].sort((a, b) => Number(b.custom) - Number(a.custom) || b.chats - a.chats);
		return rows;
	}, [
		chip,
		customs,
		liked,
		looks,
		portraits,
		query
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-3 py-4 sm:px-5",
			children: [
				!deluxe && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setUpgradeOpen(true),
					className: "mb-4 flex w-full items-center justify-between gap-3 rounded-2xl border border-line bg-surface px-4 py-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold",
						children: "Chat sin límite de fichas"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-xs text-muted",
						children: "Fotos, voz y vídeo siguen teniendo un tope."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 rounded-full bg-pink px-3 py-1.5 text-xs font-semibold text-fg",
						children: "Ver"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold tracking-tight",
						children: "Explorar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [list.length, " fichas · las tuyas y las de la casa"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "relative block sm:w-72",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Nombre o lugar",
							className: "h-11 w-full rounded-full border border-line bg-surface pr-4 pl-10 text-sm outline-none focus-visible:outline-2 focus-visible:outline-pink"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1",
					children: CHIPS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setChip(item.id),
						className: cn("h-10 shrink-0 rounded-full px-4 text-sm font-medium", chip === item.id ? "bg-pink text-fg" : "bg-surface-2 text-muted"),
						children: item.label
					}, item.id))
				}),
				list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-sm text-muted",
					children: chip === "guardadas" ? "Todavía no guardaste ninguna ficha." : chip === "mias" ? "Aún no creaste ninguna. En Crear puedes inventar una desde cero." : "Nada coincide con esa búsqueda."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4",
					children: list.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortraitCard, { model: {
						id: model.id,
						name: model.name,
						age: model.age,
						image: model.image,
						hook: model.hook,
						chats: model.chats,
						likes: model.likes,
						badge: model.custom ? "Tuya" : BADGE[model.style]
					} }, model.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 pb-6 text-xs leading-relaxed text-muted",
					children: "La IA adapta cada ficha en el chat y puede mandar foto, voz o vídeo. Sin contenido sexual."
				})
			]
		})
	});
}
//#endregion
export { Explore as component };
