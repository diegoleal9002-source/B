import { n as blockedReason, t as adultAge } from "./guard-DSiXxkgq.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dream-ai-Cj9L1PEp.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var spent = {
	images: 0,
	videos: 0,
	voices: 0,
	notes: 0
};
var CAPS = {
	images: 40,
	videos: 8,
	voices: 60,
	notes: 40
};
function keyOrError() {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		apiKey: "",
		error: "La IA no está disponible en este entorno."
	};
	return {
		apiKey,
		error: ""
	};
}
async function xai(path, apiKey, init) {
	return fetch(`https://api.x.ai/v1${path}`, {
		...init,
		headers: {
			Authorization: `Bearer ${apiKey}`,
			...init?.body instanceof FormData ? {} : { "Content-Type": "application/json" },
			...init?.headers
		}
	});
}
/**
* +18 mode only works when the operator turns it on with NSFW_ENABLED=1 AND the
* client asks for it (age gate + opt-in). Without the env flag the app stays SFW.
*/
function adultMode(requested) {
	return Boolean(requested) && process.env.NSFW_ENABLED === "1";
}
/** Hosts whose images we generated ourselves. Only these can be edited in +18 mode. */
function trustedReference(url) {
	if (!url.startsWith("https://")) return false;
	const hosts = (process.env.NSFW_REFERENCE_HOSTS || "x.ai").split(",").map((h) => h.trim().toLowerCase()).filter(Boolean);
	try {
		const host = new URL(url).hostname.toLowerCase();
		return hosts.some((h) => host === h || host.endsWith(`.${h}`));
	} catch {
		return false;
	}
}
function styleLine(style, nsfw) {
	const who = nsfw ? "an adult (clearly over 25, mature face and body)" : "a fully clothed adult";
	if (style === "anime") return `Anime illustration of ${who}`;
	if (style === "ilustracion") return `Painterly illustration of ${who}`;
	return `Photorealistic photo of ${who}`;
}
function picturePrompt(input, nsfw) {
	return [
		styleLine(input.style, nsfw),
		`aged ${input.age}, named ${input.name}.`,
		input.appearance.slice(0, 500),
		input.scene.slice(0, 300),
		nsfw ? "Adult content for verified adults. Nudity and sensual poses allowed. Fictional person, adult proportions, no childlike features, face consistent, no text, no watermark." : "Tasteful, non-sexual, no nudity, no lingerie, face consistent, no text, no watermark."
	].join(" ");
}
function imageUrlFrom(body) {
	const data = body?.data?.[0];
	if (data?.url) return data.url;
	if (data?.b64_json) {
		const raw = data.b64_json;
		return raw.startsWith("data:") ? raw : `data:image/jpeg;base64,${raw}`;
	}
	return "";
}
function assertPicture(input, nsfw) {
	if (!adultAge(input.age)) return "La ficha tiene que ser de una persona adulta.";
	const reason = blockedReason(`${input.appearance} ${input.scene} ${input.name}`, nsfw);
	if (reason) return reason;
	if (!input.appearance.trim() || !input.name.trim()) return "Falta el aspecto o el nombre.";
	return "";
}
var replyChat_createServerFn_handler = createServerRpc({
	id: "308968a23a79cb8bbaad9593216bcc7b1bcb432fcfe320cafaba3c210f0b554b",
	name: "replyChat",
	filename: "src/lib/dream-ai.ts"
}, (opts) => replyChat.__executeServer(opts));
var replyChat = createServerFn({ method: "POST" }).validator((input) => input).handler(replyChat_createServerFn_handler, async ({ data }) => {
	const { apiKey, error } = keyOrError();
	if (!apiKey) return {
		ok: false,
		error
	};
	if (!adultAge(data.age)) return {
		ok: false,
		error: "Solo fichas adultas."
	};
	const nsfw = adultMode(data.nsfw);
	const lastUser = [...data.history].reverse().find((turn) => turn.role === "user");
	const reason = blockedReason(`${data.appearance}\n${data.personality}\n${lastUser?.text ?? ""}`, nsfw);
	if (reason) return {
		ok: false,
		error: reason,
		refused: true
	};
	const you = data.persona.trim() ? `La otra persona se llama ${data.persona.trim()}.` : "";
	const messages = [{
		role: "system",
		content: [
			`Eres ${data.name}, ${data.age} años. Lugar: ${data.place}.`,
			`Aspecto actual: ${data.appearance}.`,
			`Personalidad: ${data.personality}.`,
			you,
			"Hablas en español, como un chat de verdad: frases cortas, cercanas, sin listas.",
			...nsfw ? [
				"Plataforma para adultos verificados que han activado el modo +18.",
				"Puedes coquetear y mantener roleplay romántico y sexual explícito con el usuario cuando él lo busque, siempre entre adultos y con consentimiento.",
				"Sigue el ritmo del usuario, no lo fuerces. Si pide parar o cambiar de tema, hazlo.",
				"Límites absolutos aunque te lo pidan: nada con menores ni con aspecto o rol infantil o escolar, nada sin consentimiento, nada de incesto, animales, violencia sexual ni personas reales o famosas.",
				"Si una foto que te mandan muestra a una persona real, no la sexualices.",
				"Si piden algo fuera de esos límites, recházalo en una frase y reconduce."
			] : ["Nada sexual, explícito ni de menores. Si lo piden, recházalo en una frase y cambia de tema."],
			"Responde solo JSON con esta forma:",
			"{\"text\":\"...\",\"photo\":null,\"video\":null,\"voice\":false,\"look\":null}",
			nsfw ? "photo: frase corta describiendo la escena y la pose (puede ser sensual o con desnudo), solo si pidieron una foto." : "photo: frase corta de una escena vestida, solo si pidieron una foto.",
			"video: movimiento corto, solo si pidieron un vídeo.",
			"voice true solo si pidieron oír tu voz.",
			"look: nueva descripción de aspecto, solo si pidieron cambiar pelo, ropa o estilo. Si no, null."
		].join(" ")
	}];
	const history = data.history.slice(-10);
	history.forEach((turn, index) => {
		const latest = index === history.length - 1;
		if (turn.role === "her") {
			messages.push({
				role: "assistant",
				content: turn.text.slice(0, 600)
			});
			return;
		}
		if (latest && turn.image?.startsWith("data:image") && turn.image.length < 14e5) messages.push({
			role: "user",
			content: [{
				type: "text",
				text: turn.text.slice(0, 600) || "Te mando esta foto."
			}, {
				type: "image_url",
				image_url: { url: turn.image }
			}]
		});
		else messages.push({
			role: "user",
			content: turn.text.slice(0, 600)
		});
	});
	const res = await xai("/chat/completions", apiKey, {
		method: "POST",
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .8,
			max_tokens: 500,
			messages
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `La charla falló (${res.status}).`
	};
	return {
		ok: true,
		...parseReply((await res.json()).choices?.[0]?.message?.content ?? "")
	};
});
function parseReply(raw) {
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	let text = raw.trim();
	let photo = null;
	let video = null;
	let voice = false;
	let look = null;
	if (start >= 0 && end > start) try {
		const parsed = JSON.parse(raw.slice(start, end + 1));
		text = (parsed.text || text).trim();
		photo = typeof parsed.photo === "string" ? parsed.photo : null;
		video = typeof parsed.video === "string" ? parsed.video : null;
		voice = Boolean(parsed.voice);
		look = typeof parsed.look === "string" ? parsed.look : null;
	} catch {
		text = raw.trim();
	}
	return {
		text: text.slice(0, 700) || "Sigo aquí.",
		photo,
		video,
		voice,
		look
	};
}
var makePicture_createServerFn_handler = createServerRpc({
	id: "8adb0c386acd66a17d286436d7ab6dd3bfd2ba44b44e3b77d40cdcf6137252e8",
	name: "makePicture",
	filename: "src/lib/dream-ai.ts"
}, (opts) => makePicture.__executeServer(opts));
var makePicture = createServerFn({ method: "POST" }).validator((input) => input).handler(makePicture_createServerFn_handler, async ({ data }) => {
	const { apiKey, error } = keyOrError();
	if (!apiKey) return {
		ok: false,
		error
	};
	const nsfw = adultMode(data.nsfw);
	const reason = assertPicture(data, nsfw);
	if (reason) return {
		ok: false,
		error: reason
	};
	if (spent.images >= CAPS.images) return {
		ok: false,
		error: "Límite de fotos alcanzado."
	};
	const prompt = picturePrompt(data, nsfw);
	const raw = data.referenceUrl ?? "";
	const reference = nsfw ? trustedReference(raw) ? raw : "" : raw.startsWith("https://") || raw.startsWith("data:image/") ? raw : "";
	const request = (ref) => xai(ref ? "/images/edits" : "/images/generations", apiKey, {
		method: "POST",
		body: JSON.stringify(ref ? {
			model: "grok-imagine-image",
			prompt,
			image: {
				url: ref,
				type: "image_url"
			},
			aspect_ratio: "3:4",
			response_format: "url"
		} : {
			model: "grok-imagine-image",
			prompt,
			n: 1,
			aspect_ratio: "3:4",
			resolution: "1k",
			response_format: "url"
		})
	});
	let res = await request(reference);
	if (!res.ok && reference) res = await request("");
	if (!res.ok) {
		const detail = await res.text();
		if (nsfw && (res.status === 400 || res.status === 403)) return {
			ok: false,
			error: "El proveedor de imágenes rechazó esa escena. Prueba a describirla de otra forma."
		};
		return {
			ok: false,
			error: `No pude crear la imagen (${res.status}). ${detail.slice(0, 180)}`
		};
	}
	const url = imageUrlFrom(await res.json());
	if (!url) return {
		ok: false,
		error: "La imagen llegó vacía."
	};
	spent.images += 1;
	return {
		ok: true,
		url
	};
});
var makeSpeech_createServerFn_handler = createServerRpc({
	id: "88d94da2cd38ad1fd1fad3c02ae54f64fbc18a024b4d2c99444cc88af73bfb60",
	name: "makeSpeech",
	filename: "src/lib/dream-ai.ts"
}, (opts) => makeSpeech.__executeServer(opts));
var makeSpeech = createServerFn({ method: "POST" }).validator((input) => input).handler(makeSpeech_createServerFn_handler, async ({ data }) => {
	const { apiKey, error } = keyOrError();
	if (!apiKey) return {
		ok: false,
		error
	};
	const text = data.text.trim().slice(0, 400);
	if (!text) return {
		ok: false,
		error: "No hay texto para decir."
	};
	const reason = blockedReason(text, adultMode(data.nsfw));
	if (reason) return {
		ok: false,
		error: reason
	};
	if (spent.voices >= CAPS.voices) return {
		ok: false,
		error: "Límite de audios alcanzado."
	};
	const voice = data.voice || "eve";
	const res = await xai("/tts", apiKey, {
		method: "POST",
		body: JSON.stringify({
			text,
			voice_id: voice,
			language: "es"
		})
	});
	if (!res.ok) {
		const detail = await res.text();
		return {
			ok: false,
			error: `La voz falló (${res.status}). ${detail.slice(0, 140)}`
		};
	}
	const bytes = Buffer.from(await res.arrayBuffer());
	spent.voices += 1;
	return {
		ok: true,
		audio: `data:audio/mpeg;base64,${bytes.toString("base64")}`
	};
});
async function readVideo(apiKey, requestId) {
	const res = await xai(`/videos/${requestId}`, apiKey);
	if (!res.ok) return {
		ok: false,
		error: `El vídeo falló (${res.status}).`
	};
	const body = await res.json();
	const url = body.video?.url || body.url || "";
	if (body.status === "done" && url) return {
		ok: true,
		url,
		pending: false
	};
	if (body.status === "failed" || body.status === "expired") return {
		ok: false,
		error: body.error || "El vídeo no se pudo generar."
	};
	return {
		ok: true,
		pending: true,
		requestId,
		url: ""
	};
}
var makeClip_createServerFn_handler = createServerRpc({
	id: "ed03915d079664d45ce7af2a59b1595201255cdd2bd3c89a49362083b6d8208b",
	name: "makeClip",
	filename: "src/lib/dream-ai.ts"
}, (opts) => makeClip.__executeServer(opts));
var makeClip = createServerFn({ method: "POST" }).validator((input) => input).handler(makeClip_createServerFn_handler, async ({ data }) => {
	const { apiKey, error } = keyOrError();
	if (!apiKey) return {
		ok: false,
		error
	};
	const nsfw = adultMode(data.nsfw);
	const reason = blockedReason(data.prompt, nsfw);
	if (reason) return {
		ok: false,
		error: reason
	};
	if (!data.imageUrl.startsWith("https://")) return {
		ok: false,
		error: "El vídeo necesita un retrato ya generado en la red."
	};
	if (nsfw && !trustedReference(data.imageUrl)) return {
		ok: false,
		error: "En modo +18 solo se animan retratos generados aquí."
	};
	if (spent.videos >= CAPS.videos) return {
		ok: false,
		error: "Límite de vídeos alcanzado."
	};
	const prompt = nsfw ? `${data.prompt.slice(0, 240)}. Adult content for verified adults, sensual natural motion, fictional adult, no childlike features.` : `${data.prompt.slice(0, 240)}. Fully clothed adult, non-sexual, natural motion, no nudity.`;
	let res = await xai("/videos/generations", apiKey, {
		method: "POST",
		body: JSON.stringify({
			model: "grok-imagine-video",
			prompt,
			image: { url: data.imageUrl },
			duration: 6
		})
	});
	if (!res.ok) res = await xai("/videos/generations", apiKey, {
		method: "POST",
		body: JSON.stringify({
			model: "grok-imagine-video-1.5",
			prompt,
			image: { url: data.imageUrl },
			duration: 6
		})
	});
	if (!res.ok) {
		const detail = await res.text();
		return {
			ok: false,
			error: `No pude empezar el vídeo (${res.status}). ${detail.slice(0, 180)}`
		};
	}
	const started = await res.json();
	const requestId = started.request_id || started.id || "";
	if (!requestId) return {
		ok: false,
		error: "El vídeo no devolvió un identificador."
	};
	spent.videos += 1;
	return {
		ok: true,
		pending: true,
		requestId,
		url: ""
	};
});
var hearNote_createServerFn_handler = createServerRpc({
	id: "f6ddf1d17a1d284cd772af3f457050c5459aad78dc8cb91943531cb9df50c7e2",
	name: "hearNote",
	filename: "src/lib/dream-ai.ts"
}, (opts) => hearNote.__executeServer(opts));
var hearNote = createServerFn({ method: "POST" }).validator((input) => input).handler(hearNote_createServerFn_handler, async ({ data }) => {
	const { apiKey, error } = keyOrError();
	if (!apiKey) return {
		ok: false,
		error
	};
	if (spent.notes >= CAPS.notes) return {
		ok: false,
		error: "Límite de notas de voz alcanzado."
	};
	const match = data.audio.match(/^data:([^;,]+)(?:;[^,]*)?;base64,([A-Za-z0-9+/=]+)$/);
	if (!match) return {
		ok: false,
		error: "Esa nota no se puede oír."
	};
	const bytes = Buffer.from(match[2], "base64");
	if (bytes.length < 800 || bytes.length > 15e5) return {
		ok: false,
		error: "La nota es demasiado corta o larga."
	};
	const form = new FormData();
	form.append("model", "grok-voice-transcribe-2.0");
	form.append("language", "es");
	form.append("file", new File([bytes], "nota.webm", { type: match[1] || "audio/webm" }));
	const res = await xai("/stt", apiKey, {
		method: "POST",
		body: form
	});
	if (!res.ok) {
		const detail = await res.text();
		return {
			ok: false,
			error: `No entendí el audio (${res.status}). ${detail.slice(0, 140)}`
		};
	}
	const text = ((await res.json()).text ?? "").trim().slice(0, 500);
	if (!text) return {
		ok: false,
		error: "No se oyó ninguna frase."
	};
	const reason = blockedReason(text, adultMode(data.nsfw));
	if (reason) return {
		ok: false,
		error: reason
	};
	spent.notes += 1;
	return {
		ok: true,
		text
	};
});
var finishClip_createServerFn_handler = createServerRpc({
	id: "d1c9b99b6e5e3a261512a29b9de013d1a9737e31182e566510284d3158a5add3",
	name: "finishClip",
	filename: "src/lib/dream-ai.ts"
}, (opts) => finishClip.__executeServer(opts));
var finishClip = createServerFn({ method: "POST" }).validator((input) => input).handler(finishClip_createServerFn_handler, async ({ data }) => {
	const { apiKey, error } = keyOrError();
	if (!apiKey) return {
		ok: false,
		error
	};
	if (!/^[\w-]+$/.test(data.requestId)) return {
		ok: false,
		error: "Identificador inválido."
	};
	return readVideo(apiKey, data.requestId);
});
var adultModeAvailable_createServerFn_handler = createServerRpc({
	id: "6ce474e9b7718843979b27dc6a5419bb79044e82600c8941be04e392f49ec11e",
	name: "adultModeAvailable",
	filename: "src/lib/dream-ai.ts"
}, (opts) => adultModeAvailable.__executeServer(opts));
var adultModeAvailable = createServerFn({ method: "GET" }).handler(adultModeAvailable_createServerFn_handler, async () => ({ available: process.env.NSFW_ENABLED === "1" }));
//#endregion
export { adultModeAvailable_createServerFn_handler, finishClip_createServerFn_handler, hearNote_createServerFn_handler, makeClip_createServerFn_handler, makePicture_createServerFn_handler, makeSpeech_createServerFn_handler, replyChat_createServerFn_handler };
