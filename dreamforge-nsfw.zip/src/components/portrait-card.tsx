import { Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { formatCount } from "@/data/cast";
import { cn } from "@/lib/cn";
import { useDream } from "@/lib/store";

export type CardFace = {
  id: string;
  name: string;
  age: number;
  image: string;
  hook: string;
  chats: number;
  likes: number;
  badge: string;
};

export function PortraitCard({ model }: { model: CardFace }) {
  const liked = useDream((s) => s.liked.includes(model.id));
  const toggleLike = useDream((s) => s.toggleLike);
  const likes = model.likes + (liked ? 1 : 0);

  return (
    <article className="group relative overflow-hidden rounded-2xl bg-surface">
      <Link to="/c/$id" params={{ id: model.id }} className="block">
        <img
          src={model.image}
          alt={`${model.name}, ${model.age}`}
          className="aspect-3/4 w-full object-cover transition duration-300 group-hover:scale-105"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-ink/15 to-transparent" />
        <div className="absolute top-2.5 left-2.5 rounded-full bg-ink/70 px-2.5 py-1 text-xs font-medium text-fg">
          {model.badge}
        </div>
        <div className="absolute inset-x-0 bottom-0 p-3">
          <div className="flex items-baseline gap-2">
            <h2 className="text-base font-semibold tracking-tight">{model.name}</h2>
            <span className="text-sm text-fg/75">{model.age}</span>
          </div>
          <p className="mt-1 line-clamp-2 text-xs leading-snug text-fg/80">{model.hook}</p>
          <p className="mt-2 text-xs text-fg/60">{formatCount(model.chats)} chats</p>
        </div>
      </Link>
      <button
        type="button"
        aria-pressed={liked}
        aria-label={liked ? `Quitar me gusta a ${model.name}` : `Guardar a ${model.name}`}
        onClick={() => toggleLike(model.id)}
        className="absolute top-2 right-2 grid size-10 place-items-center rounded-full bg-ink/70"
      >
        <Heart className={cn("size-4", liked ? "fill-pink text-pink" : "text-fg")} />
        <span className="sr-only">{formatCount(likes)}</span>
      </button>
    </article>
  );
}
