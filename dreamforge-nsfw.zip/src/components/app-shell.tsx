import { Link, useRouterState } from "@tanstack/react-router";
import * as Dialog from "@radix-ui/react-dialog";
import * as Popover from "@radix-ui/react-popover";
import { Check, Coins, Compass, Flame, MessageCircle, Plus, Sparkles, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/lib/cn";
import { adultModeAvailable } from "@/lib/dream-ai";
import { yearsSince } from "@/lib/guard";
import { useDream } from "@/lib/store";

const NAV = [
  { to: "/", label: "Explorar", icon: Compass, exact: true },
  { to: "/chats", label: "Chats", icon: MessageCircle, exact: false },
  { to: "/crear", label: "Crear", icon: Plus, exact: false },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const finish = () => setReady(true);
    if (useDream.persist.hasHydrated()) finish();
    const unsub = useDream.persist.onFinishHydration(finish);
    const timer = window.setTimeout(finish, 2000);
    return () => {
      unsub?.();
      window.clearTimeout(timer);
    };
  }, []);

  if (!ready) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg text-fg">
        <p className="text-xl font-extrabold tracking-tight">
          Dream<span className="text-pink">Forge</span>
        </p>
      </div>
    );
  }

  return (
    <div className="flex h-dvh flex-col bg-bg text-fg">
      <TopBar />
      <main className="min-h-0 flex-1 overflow-hidden">{children}</main>
      <BottomNav />
      <AgeGate />
      <AdultModeDialog />
      <UpgradeDialog />
    </div>
  );
}

function isNavActive(path: string, item: { to: string; exact: boolean }) {
  if (item.exact) return path === item.to;
  if (item.to === "/chats") return path === "/chats" || path.startsWith("/c/");
  return path === item.to || path.startsWith(`${item.to}/`);
}

function TopBar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const deluxe = useDream((s) => s.deluxe);
  const coins = useDream((s) => s.coins);
  const setUpgradeOpen = useDream((s) => s.setUpgradeOpen);

  return (
    <header className="z-20 flex h-16 shrink-0 items-center gap-3 border-b border-line bg-bg/90 px-3 backdrop-blur-md sm:px-5">
      <Link to="/" className="flex items-center gap-2 text-lg font-extrabold tracking-tight">
        <span className="grid size-8 place-items-center rounded-xl bg-pink text-fg">
          <Sparkles className="size-4" aria-hidden="true" />
        </span>
        <span className="hidden sm:inline">
          Dream<span className="text-pink">Forge</span>
        </span>
      </Link>

      <nav className="ml-4 hidden items-center gap-1 lg:flex">
        {NAV.map((item) => {
          const active = isNavActive(path, item);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "rounded-full px-4 py-2 text-sm font-medium",
                active ? "bg-surface-2 text-fg" : "text-muted hover:text-fg",
              )}
            >
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="ml-auto flex items-center gap-2">
        <AdultToggle />
        <button
          type="button"
          onClick={() => setUpgradeOpen(true)}
          className="flex items-center gap-1.5 rounded-full bg-surface-2 px-3 py-2 text-sm"
        >
          <Coins className="size-4 text-coin" aria-hidden="true" />
          <span className="font-semibold text-coin">{deluxe ? "∞" : coins}</span>
        </button>
        {deluxe ? (
          <span className="hidden rounded-full border border-line px-4 py-2 text-sm font-semibold text-coin sm:inline">
            Deluxe
          </span>
        ) : (
          <button
            type="button"
            onClick={() => setUpgradeOpen(true)}
            className="rounded-full bg-pink px-3 py-2 text-sm font-semibold text-fg sm:px-4"
          >
            Deluxe
          </button>
        )}
        <PersonaButton />
      </div>
    </header>
  );
}

function PersonaButton() {
  const persona = useDream((s) => s.persona);
  const setPersona = useDream((s) => s.setPersona);
  const initial = (persona.trim() || "Tú").slice(0, 1).toUpperCase();

  return (
    <Popover.Root>
      <Popover.Trigger
        className="grid size-10 place-items-center rounded-full border border-line bg-surface-2 text-sm font-semibold"
        aria-label="Tu nombre en el chat"
      >
        {initial}
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content
          align="end"
          sideOffset={8}
          className="z-40 w-64 rounded-2xl border border-line bg-surface p-4 shadow-2xl"
        >
          <p className="text-sm font-semibold">Cómo te llaman</p>
          <p className="mt-1 text-xs text-muted">Solo vive en este navegador.</p>
          <input
            value={persona}
            onChange={(event) => setPersona(event.target.value)}
            placeholder="Tu nombre"
            className="mt-3 w-full rounded-xl border border-line bg-bg px-3 py-2 text-sm outline-none focus-visible:outline-2 focus-visible:outline-pink"
          />
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}

function BottomNav() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="grid h-16 shrink-0 grid-cols-3 border-t border-line bg-bg lg:hidden">
      {NAV.map((item) => {
        const active = isNavActive(path, item);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "flex flex-col items-center justify-center gap-1 text-xs",
              active ? "text-pink" : "text-muted",
            )}
          >
            <Icon className="size-5" aria-hidden="true" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

function AgeGate() {
  const adultOk = useDream((s) => s.adultOk);
  const birthDate = useDream((s) => s.birthDate);
  const acceptAdult = useDream((s) => s.acceptAdult);
  const [birth, setBirth] = useState("");
  const [checked, setChecked] = useState(false);
  const [error, setError] = useState("");
  if (adultOk && birthDate) return null;

  function enter() {
    const years = yearsSince(birth);
    if (!birth || years < 18 || years > 110) {
      setError("Tienes que ser mayor de 18 años para entrar.");
      return;
    }
    acceptAdult(birth);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink px-5">
      <div className="w-full max-w-md">
        <p className="text-xs font-semibold tracking-widest text-pink uppercase">Solo adultos</p>
        <h1 className="mt-3 text-4xl font-extrabold tracking-tight">Mayores de 18</h1>
        <p className="mt-3 text-base leading-relaxed text-muted">
          DreamForge es un chat de compañía con personajes ficticios adultos. Puede incluir contenido sexual
          explícito si activas el modo +18. Todos los personajes son mayores de edad e inventados.
        </p>
        <label className="mt-6 block text-xs font-semibold tracking-wide text-muted uppercase">
          Fecha de nacimiento
          <input
            type="date"
            value={birth}
            max={new Date().toISOString().slice(0, 10)}
            onChange={(event) => {
              setBirth(event.target.value);
              setError("");
            }}
            className="mt-2 h-11 w-full rounded-2xl border border-line bg-surface px-4 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
          />
        </label>
        <label className="mt-4 flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" checked={checked} onChange={(event) => setChecked(event.target.checked)} />
          Confirmo que soy mayor de edad en mi país y acepto ver contenido para adultos
        </label>
        {error && <p className="mt-2 text-sm text-pink">{error}</p>}
        <button
          type="button"
          disabled={!checked || !birth}
          onClick={enter}
          className="mt-4 h-12 w-full rounded-full bg-pink text-sm font-semibold text-fg disabled:opacity-40"
        >
          Entrar
        </button>
        <a href="https://www.google.com" className="mt-3 block text-center text-sm text-muted underline">
          Salir
        </a>
      </div>
    </div>
  );
}

function useAdultAvailable() {
  const [available, setAvailable] = useState<boolean | null>(null);
  useEffect(() => {
    let live = true;
    adultModeAvailable()
      .then((r) => live && setAvailable(r.available))
      .catch(() => live && setAvailable(false));
    return () => {
      live = false;
    };
  }, []);
  return available;
}

let openAdultDialog: (() => void) | null = null;

function AdultToggle() {
  const nsfw = useDream((s) => s.nsfw);
  const setNsfw = useDream((s) => s.setNsfw);
  const available = useAdultAvailable();
  useEffect(() => {
    if (available === false && nsfw) setNsfw(false);
  }, [available, nsfw, setNsfw]);
  if (!available) return null;

  return (
    <button
      type="button"
      aria-pressed={nsfw}
      onClick={() => (nsfw ? setNsfw(false) : openAdultDialog?.())}
      className={cn(
        "flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-semibold",
        nsfw ? "bg-pink text-fg" : "bg-surface-2 text-muted",
      )}
      title={nsfw ? "Modo +18 activo. Pulsa para desactivar." : "Activar modo +18"}
    >
      <Flame className="size-4" aria-hidden="true" />
      +18
    </button>
  );
}

function AdultModeDialog() {
  const [open, setOpen] = useState(false);
  const setNsfw = useDream((s) => s.setNsfw);
  const blurNsfw = useDream((s) => s.blurNsfw);
  const setBlurNsfw = useDream((s) => s.setBlurNsfw);
  useEffect(() => {
    openAdultDialog = () => setOpen(true);
    return () => {
      openAdultDialog = null;
    };
  }, []);

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-ink/80" />
        <Dialog.Content className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-3xl border border-line bg-surface p-6">
          <Dialog.Title className="text-2xl font-extrabold tracking-tight">Activar modo +18</Dialog.Title>
          <Dialog.Description className="mt-2 text-sm leading-relaxed text-muted">
            Los personajes podrán tener conversaciones, fotos y vídeos sexuales explícitos contigo.
          </Dialog.Description>
          <ul className="mt-4 space-y-2 text-sm">
            {[
              "Todos los personajes son adultos y ficticios",
              "Nada con menores, sin consentimiento, incesto o animales",
              "Nada sobre personas reales ni a partir de fotos tuyas o de otros",
            ].map((item) => (
              <li key={item} className="flex items-start gap-2">
                <Check className="mt-0.5 size-4 shrink-0 text-pink" aria-hidden="true" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <label className="mt-4 flex min-h-11 items-center gap-3 text-sm">
            <input type="checkbox" checked={blurNsfw} onChange={(e) => setBlurNsfw(e.target.checked)} />
            Difuminar fotos y vídeos +18 hasta que los toque
          </label>
          <div className="mt-5 flex gap-2">
            <Dialog.Close className="h-12 flex-1 rounded-full bg-surface-2 text-sm font-semibold">Cancelar</Dialog.Close>
            <button
              type="button"
              onClick={() => {
                setNsfw(true);
                setOpen(false);
              }}
              className="h-12 flex-1 rounded-full bg-pink text-sm font-semibold text-fg"
            >
              Activar
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

function UpgradeDialog() {
  const open = useDream((s) => s.upgradeOpen);
  const setUpgradeOpen = useDream((s) => s.setUpgradeOpen);
  const deluxe = useDream((s) => s.deluxe);
  const unlockDeluxe = useDream((s) => s.unlockDeluxe);

  return (
    <Dialog.Root open={open} onOpenChange={setUpgradeOpen}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-ink/80" />
        <Dialog.Content className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-3xl border border-line bg-surface p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="text-2xl font-extrabold tracking-tight">Pasa a Deluxe</Dialog.Title>
              <Dialog.Description className="mt-2 text-sm leading-relaxed text-muted">
                Demo local. No hay cobro ni cuenta. Solo quita el límite de fichas en este navegador.
              </Dialog.Description>
            </div>
            <Dialog.Close className="grid size-10 place-items-center rounded-full bg-surface-2" aria-label="Cerrar">
              <X className="size-4" />
            </Dialog.Close>
          </div>
          <ul className="mt-5 space-y-3 text-sm">
            {[
              "Chat sin gastar fichas",
              "Las ocho fichas, con el mismo retrato fijo",
              "Tu nombre y las conversaciones se quedan aquí",
            ].map((item) => (
              <li key={item} className="flex items-start gap-2">
                <Check className="mt-0.5 size-4 shrink-0 text-pink" aria-hidden="true" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={unlockDeluxe}
            disabled={deluxe}
            className="mt-6 h-12 w-full rounded-full bg-pink text-sm font-semibold text-fg disabled:opacity-50"
          >
            {deluxe ? "Deluxe activo" : "Activar Deluxe"}
          </button>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
