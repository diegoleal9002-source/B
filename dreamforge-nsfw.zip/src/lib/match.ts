import { CAST, type Eyes, type Hair, type Model, type Presence, type Silhouette } from "@/data/cast";

export type PickTraits = {
  hair: Hair;
  eyes: Eyes;
  presence: Presence;
  silhouette: Silhouette;
  age: number;
};

export const DEFAULT_PICK: PickTraits = {
  hair: "rubio",
  eyes: "claros",
  presence: "marcado",
  silhouette: "marcada",
  age: 32,
};

const MAX_SCORE = 10;

export function likeness(model: Model, pick: PickTraits) {
  let score = 0;
  const hits: string[] = [];
  if (model.hair === pick.hair) {
    score += 3;
    hits.push("pelo");
  }
  if (model.eyes === pick.eyes) {
    score += 2;
    hits.push("ojos");
  }
  if (model.presence === pick.presence) {
    score += 2;
    hits.push("presencia");
  }
  if (model.silhouette === pick.silhouette) {
    score += 1;
    hits.push("silueta");
  }
  if (model.age === pick.age) {
    score += 2;
    hits.push("edad");
  }
  return { score, hits, max: MAX_SCORE };
}

export function rankModels(pick: PickTraits) {
  return [...CAST].sort((a, b) => {
    const delta = likeness(b, pick).score - likeness(a, pick).score;
    if (delta !== 0) return delta;
    return b.chats - a.chats;
  });
}
