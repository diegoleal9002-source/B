import { createServerFn } from "@tanstack/react-start";
import { adultAge, blockedReason } from "@/lib/guard";
import type { Style } from "@/lib/roster";

type Turn = { role: "user" | "her"; text: string; image?: string };

type ReplyInput = {
  name: string;
  age: number;
  appearance: string;
  personality: string;
  place: string;
  persona: string;
  history: Turn[];
  nsfw?: boolean;
};

type PictureInput = {
  name: string;
  age: number;
  style: Style;
  appearance: string;
  scene: string;
  referenceUrl?: string;
  nsfw?: boolean;
};

type SpeechInput = { text: string; voice: string; nsfw?: boolean };
type ClipInput = { prompt: string; imageUrl: string; nsfw?: boolean };
type PollInput = { requestId: string };

const spent = { images: 0, videos: 0, voices: 0, notes: 0 };
const CAPS = { images: 40, videos: 8, voices: 60, notes: 40 };

function keyOrError() {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { apiKey: "", error: "La IA no está disponible en este entorno." };
  return { apiKey, error: "" };
}

async function xai(path: string, apiKey: string, init?: RequestInit) {
  return fetch(`https://api.x.ai/v1${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      ...(init?.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...init?.headers,
    },
  });
}

/**
 * +18 mode only works when the operator turns it on with NSFW_ENABLED=1 AND the
 * client asks for it (age gate + opt-in). Without the env flag the app stays SFW.
 */
function adultMode(requested?: boolean) {
  return Boolean(requested) && process.env.NSFW_ENABLED === "1";
}

/** Hosts whose images we generated ourselves. Only these can be edited in +18 mode. */
function trustedReference(url: string) {
  if (!url.startsWith("https://")) return false;
  const hosts = (process.env.NSFW_REFERENCE_HOSTS || "x.ai")
    .split(",")
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean);
  try {
    const host = new URL(url).hostname.toLowerCase();
    return hosts.some((h) => host === h || host.endsWith(`.${h}`));
  } catch {
    return false;
  }
}

function styleLine(style: Style, nsfw: boolean) {
  const who = nsfw ? "an adult (clearly over 25, mature face and body)" : "a fully clothed adult";
  if (style === "anime") return `Anime illustration of ${who}`;
  if (style === "ilustracion") return `Painterly illustration of ${who}`;
  return `Photorealistic photo of ${who}`;
}

function picturePrompt(input: PictureInput, nsfw: boolean) {
  return [
    styleLine(input.style, nsfw),
    `aged ${input.age}, named ${input.name}.`,
    input.appearance.slice(0, 500),
    input.scene.slice(0, 300),
    nsfw
      ? "Adult content for verified adults. Nudity and sensual poses allowed. Fictional person, adult proportions, no childlike features, face consistent, no text, no watermark."
      : "Tasteful, non-sexual, no nudity, no lingerie, face consistent, no text, no watermark.",
  ].join(" ");
}

function imageUrlFrom(body: unknown): string {
  const data = (body as { data?: { url?: string; b64_json?: string }[] })?.data?.[0];
  if (data?.url) return data.url;
  if (data?.b64_json) {
    const raw = data.b64_json;
    return raw.startsWith("data:") ? raw : `data:image/jpeg;base64,${raw}`;
  }
  return "";
}

function assertPicture(input: PictureInput, nsfw: boolean) {
  if (!adultAge(input.age)) return "La ficha tiene que ser de una persona adulta.";
  const reason = blockedReason(`${input.appearance} ${input.scene} ${input.name}`, nsfw);
  if (reason) return reason;
  if (!input.appearance.trim() || !input.name.trim()) return "Falta el aspecto o el nombre.";
  return "";
}

export const replyChat = createServerFn({ method: "POST" })
  .validator((input: ReplyInput) => input)
  .handler(async ({ data }) => {
    const { apiKey, error } = keyOrError();
    if (!apiKey) return { ok: false as const, error };
    if (!adultAge(data.age)) return { ok: false as const, error: "Solo fichas adultas." };
    const nsfw = adultMode(data.nsfw);
    const lastUser = [...data.history].reverse().find((turn) => turn.role === "user");
    const reason = blockedReason(`${data.appearance}\n${data.personality}\n${lastUser?.text ?? ""}`, nsfw);
    if (reason) return { ok: false as const, error: reason, refused: true as const };

    const you = data.persona.trim() ? `La otra persona se llama ${data.persona.trim()}.` : "";
    const system = [
      `Eres ${data.name}, ${data.age} años. Lugar: ${data.place}.`,
      `Aspecto actual: ${data.appearance}.`,
      `Personalidad: ${data.personality}.`,
      you,
      "Hablas en español, como un chat de verdad: frases cortas, cercanas, sin listas.",
      ...(nsfw
        ? [
            "Plataforma para adultos verificados que han activado el modo +18.",
            "Puedes coquetear y mantener roleplay romántico y sexual explícito con el usuario cuando él lo busque, siempre entre adultos y con consentimiento.",
            "Sigue el ritmo del usuario, no lo fuerces. Si pide parar o cambiar de tema, hazlo.",
            "Límites absolutos aunque te lo pidan: nada con menores ni con aspecto o rol infantil o escolar, nada sin consentimiento, nada de incesto, animales, violencia sexual ni personas reales o famosas.",
            "Si una foto que te mandan muestra a una persona real, no la sexualices.",
            "Si piden algo fuera de esos límites, recházalo en una frase y reconduce.",
          ]
        : ["Nada sexual, explícito ni de menores. Si lo piden, recházalo en una frase y cambia de tema."]),
      "Responde solo JSON con esta forma:",
      '{"text":"...","photo":null,"video":null,"voice":false,"look":null}',
      nsfw
        ? "photo: frase corta describiendo la escena y la pose (puede ser sensual o con desnudo), solo si pidieron una foto."
        : "photo: frase corta de una escena vestida, solo si pidieron una foto.",
      "video: movimiento corto, solo si pidieron un vídeo.",
      "voice true solo si pidieron oír tu voz.",
      "look: nueva descripción de aspecto, solo si pidieron cambiar pelo, ropa o estilo. Si no, null.",
    ].join(" ");

    const messages: { role: "system" | "user" | "assistant"; content: unknown }[] = [
      { role: "system", content: system },
    ];
    const history = data.history.slice(-10);
    history.forEach((turn, index) => {
      const latest = index === history.length - 1;
      if (turn.role === "her") {
        messages.push({ role: "assistant", content: turn.text.slice(0, 600) });
        return;
      }
      if (latest && turn.image?.startsWith("data:image") && turn.image.length < 1_400_000) {
        messages.push({
          role: "user",
          content: [
            { type: "text", text: turn.text.slice(0, 600) || "Te mando esta foto." },
            { type: "image_url", image_url: { url: turn.image } },
          ],
        });
      } else {
        messages.push({ role: "user", content: turn.text.slice(0, 600) });
      }
    });

    const res = await xai("/chat/completions", apiKey, {
      method: "POST",
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.8,
        max_tokens: 500,
        messages,
      }),
    });
    if (!res.ok) return { ok: false as const, error: `La charla falló (${res.status}).` };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const raw = body.choices?.[0]?.message?.content ?? "";
    return { ok: true as const, ...parseReply(raw) };
  });

function parseReply(raw: string) {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  let text = raw.trim();
  let photo: string | null = null;
  let video: string | null = null;
  let voice = false;
  let look: string | null = null;
  if (start >= 0 && end > start) {
    try {
      const parsed = JSON.parse(raw.slice(start, end + 1)) as {
        text?: string;
        photo?: string | null;
        video?: string | null;
        voice?: boolean;
        look?: string | null;
      };
      text = (parsed.text || text).trim();
      photo = typeof parsed.photo === "string" ? parsed.photo : null;
      video = typeof parsed.video === "string" ? parsed.video : null;
      voice = Boolean(parsed.voice);
      look = typeof parsed.look === "string" ? parsed.look : null;
    } catch {
      text = raw.trim();
    }
  }
  return {
    text: text.slice(0, 700) || "Sigo aquí.",
    photo,
    video,
    voice,
    look,
  };
}

export const makePicture = createServerFn({ method: "POST" })
  .validator((input: PictureInput) => input)
  .handler(async ({ data }) => {
    const { apiKey, error } = keyOrError();
    if (!apiKey) return { ok: false as const, error };
    const nsfw = adultMode(data.nsfw);
    const reason = assertPicture(data, nsfw);
    if (reason) return { ok: false as const, error: reason };
    if (spent.images >= CAPS.images) return { ok: false as const, error: "Límite de fotos alcanzado." };
    const prompt = picturePrompt(data, nsfw);
    // In +18 mode never edit an arbitrary photo (could be a real person): only
    // images this app generated earlier. Otherwise, generate from text.
    const raw = data.referenceUrl ?? "";
    const reference = nsfw
      ? trustedReference(raw)
        ? raw
        : ""
      : raw.startsWith("https://") || raw.startsWith("data:image/")
        ? raw
        : "";
    const request = (ref: string) =>
      xai(ref ? "/images/edits" : "/images/generations", apiKey, {
        method: "POST",
        body: JSON.stringify(
          ref
            ? {
                model: "grok-imagine-image",
                prompt,
                image: { url: ref, type: "image_url" },
                aspect_ratio: "3:4",
                response_format: "url",
              }
            : {
                model: "grok-imagine-image",
                prompt,
                n: 1,
                aspect_ratio: "3:4",
                resolution: "1k",
                response_format: "url",
              },
        ),
      });
    let res = await request(reference);
    if (!res.ok && reference) res = await request("");
    if (!res.ok) {
      const detail = await res.text();
      if (nsfw && (res.status === 400 || res.status === 403)) {
        return { ok: false as const, error: "El proveedor de imágenes rechazó esa escena. Prueba a describirla de otra forma." };
      }
      return { ok: false as const, error: `No pude crear la imagen (${res.status}). ${detail.slice(0, 180)}` };
    }
    const url = imageUrlFrom(await res.json());
    if (!url) return { ok: false as const, error: "La imagen llegó vacía." };
    spent.images += 1;
    return { ok: true as const, url };
  });

export const makeSpeech = createServerFn({ method: "POST" })
  .validator((input: SpeechInput) => input)
  .handler(async ({ data }) => {
    const { apiKey, error } = keyOrError();
    if (!apiKey) return { ok: false as const, error };
    const text = data.text.trim().slice(0, 400);
    if (!text) return { ok: false as const, error: "No hay texto para decir." };
    const reason = blockedReason(text, adultMode(data.nsfw));
    if (reason) return { ok: false as const, error: reason };
    if (spent.voices >= CAPS.voices) return { ok: false as const, error: "Límite de audios alcanzado." };
    const voice = data.voice || "eve";
    const res = await xai("/tts", apiKey, {
      method: "POST",
      body: JSON.stringify({ text, voice_id: voice, language: "es" }),
    });
    if (!res.ok) {
      const detail = await res.text();
      return { ok: false as const, error: `La voz falló (${res.status}). ${detail.slice(0, 140)}` };
    }
    const bytes = Buffer.from(await res.arrayBuffer());
    spent.voices += 1;
    return { ok: true as const, audio: `data:audio/mpeg;base64,${bytes.toString("base64")}` };
  });

async function readVideo(apiKey: string, requestId: string) {
  const res = await xai(`/videos/${requestId}`, apiKey);
  if (!res.ok) return { ok: false as const, error: `El vídeo falló (${res.status}).` };
  const body = (await res.json()) as {
    status?: string;
    video?: { url?: string };
    url?: string;
    error?: string;
  };
  const url = body.video?.url || body.url || "";
  if (body.status === "done" && url) return { ok: true as const, url, pending: false as const };
  if (body.status === "failed" || body.status === "expired") {
    return { ok: false as const, error: body.error || "El vídeo no se pudo generar." };
  }
  return { ok: true as const, pending: true as const, requestId, url: "" };
}

export const makeClip = createServerFn({ method: "POST" })
  .validator((input: ClipInput) => input)
  .handler(async ({ data }) => {
    const { apiKey, error } = keyOrError();
    if (!apiKey) return { ok: false as const, error };
    const nsfw = adultMode(data.nsfw);
    const reason = blockedReason(data.prompt, nsfw);
    if (reason) return { ok: false as const, error: reason };
    if (!data.imageUrl.startsWith("https://")) {
      return { ok: false as const, error: "El vídeo necesita un retrato ya generado en la red." };
    }
    if (nsfw && !trustedReference(data.imageUrl)) {
      return { ok: false as const, error: "En modo +18 solo se animan retratos generados aquí." };
    }
    if (spent.videos >= CAPS.videos) return { ok: false as const, error: "Límite de vídeos alcanzado." };
    const prompt = nsfw
      ? `${data.prompt.slice(0, 240)}. Adult content for verified adults, sensual natural motion, fictional adult, no childlike features.`
      : `${data.prompt.slice(0, 240)}. Fully clothed adult, non-sexual, natural motion, no nudity.`;
    let res = await xai("/videos/generations", apiKey, {
      method: "POST",
      body: JSON.stringify({
        model: "grok-imagine-video",
        prompt,
        image: { url: data.imageUrl },
        duration: 6,
      }),
    });
    if (!res.ok) {
      res = await xai("/videos/generations", apiKey, {
        method: "POST",
        body: JSON.stringify({
          model: "grok-imagine-video-1.5",
          prompt,
          image: { url: data.imageUrl },
          duration: 6,
        }),
      });
    }
    if (!res.ok) {
      const detail = await res.text();
      return { ok: false as const, error: `No pude empezar el vídeo (${res.status}). ${detail.slice(0, 180)}` };
    }
    const started = (await res.json()) as { request_id?: string; id?: string };
    const requestId = started.request_id || started.id || "";
    if (!requestId) return { ok: false as const, error: "El vídeo no devolvió un identificador." };
    spent.videos += 1;
    return { ok: true as const, pending: true as const, requestId, url: "" };
  });

export const hearNote = createServerFn({ method: "POST" })
  .validator((input: { audio: string; nsfw?: boolean }) => input)
  .handler(async ({ data }) => {
    const { apiKey, error } = keyOrError();
    if (!apiKey) return { ok: false as const, error };
    if (spent.notes >= CAPS.notes) return { ok: false as const, error: "Límite de notas de voz alcanzado." };
    const match = data.audio.match(/^data:([^;,]+)(?:;[^,]*)?;base64,([A-Za-z0-9+/=]+)$/);
    if (!match) return { ok: false as const, error: "Esa nota no se puede oír." };
    const bytes = Buffer.from(match[2], "base64");
    if (bytes.length < 800 || bytes.length > 1_500_000) {
      return { ok: false as const, error: "La nota es demasiado corta o larga." };
    }
    const form = new FormData();
    form.append("model", "grok-voice-transcribe-2.0");
    form.append("language", "es");
    form.append("file", new File([bytes], "nota.webm", { type: match[1] || "audio/webm" }));
    const res = await xai("/stt", apiKey, { method: "POST", body: form });
    if (!res.ok) {
      const detail = await res.text();
      return { ok: false as const, error: `No entendí el audio (${res.status}). ${detail.slice(0, 140)}` };
    }
    const body = (await res.json()) as { text?: string };
    const text = (body.text ?? "").trim().slice(0, 500);
    if (!text) return { ok: false as const, error: "No se oyó ninguna frase." };
    const reason = blockedReason(text, adultMode(data.nsfw));
    if (reason) return { ok: false as const, error: reason };
    spent.notes += 1;
    return { ok: true as const, text };
  });

export const finishClip = createServerFn({ method: "POST" })
  .validator((input: PollInput) => input)
  .handler(async ({ data }) => {
    const { apiKey, error } = keyOrError();
    if (!apiKey) return { ok: false as const, error };
    if (!/^[\w-]+$/.test(data.requestId)) return { ok: false as const, error: "Identificador inválido." };
    return readVideo(apiKey, data.requestId);
  });

export const adultModeAvailable = createServerFn({ method: "GET" }).handler(async () => ({
  available: process.env.NSFW_ENABLED === "1",
}));
