import type { Model } from "@/data/cast";

const BLOCK =
  /\b(sexo|sexual|desnuda|desnudo|nude|nudes|porn|porno|nsfw|foll|coger|penetr|orgasmo|tetas|polla|coño|pussy|cock|fuck|masturb|correrme|explícit|explicit|lingerie|sin ropa)\b/i;

const PHOTO =
  /\b(genera|genérame|generame|foto nueva|otra pose|cámbiate|cambiate|quítate|quitate|desn[uú]date)\b/i;

export function replyFor(model: Model, userText: string, variant: number, persona: string) {
  const text = userText.trim();
  const lower = text.toLowerCase();
  const name = persona.trim();
  const you = name ? `, ${name}` : "";

  if (BLOCK.test(lower)) {
    return `${model.name} niega con la cabeza. «Eso no va aquí. DreamForge no arma escenas explícitas. Si quieres, seguimos hablando de otra cosa.»`;
  }
  if (PHOTO.test(lower)) {
    return "Esta ficha es un retrato fijo. No cambio de pose ni de ropa desde el chat.";
  }
  if (/^(hola|buenas|hey|ey|qué tal|que tal|buenos días|buenas noches)\b/.test(lower)) {
    return `Hola${you}. Estoy en ${model.place.toLowerCase()}. Tú dirás.`;
  }
  if (/nombre/.test(lower)) {
    return `Me llamo ${model.name}. ${model.age} años. El resto está en la cara, no en el formulario.`;
  }
  if (/edad|años|anos|cuántos|cuantos/.test(lower)) {
    return `Tengo ${model.age}. No es un dato suelto: es el ritmo con el que hablo.`;
  }
  if (/trabajo|dedic|oficio|haces|profes/.test(lower)) {
    return model.work;
  }
  if (/dónde|donde|lugar|sitio|estás|estas/.test(lower)) {
    return `Ahora mismo: ${model.place}. ${model.hook}`;
  }
  if (/quién eres|quien eres|cuéntame de ti|cuentame|sobre ti|bio/.test(lower)) {
    return model.bio;
  }
  if (/pelo|ojos|aspecto|cara/.test(lower)) {
    return `Pelo ${model.hair}, ojos ${model.eyes}. Lo demás lo estás viendo ya.`;
  }
  if (/guap|bonit|lind|me gustas|atractiv/.test(lower)) {
    return "Gracias. No hace falta convertirlo en un discurso. Sigue hablando.";
  }

  const pool = model.lines;
  return pool[Math.abs(variant) % pool.length] ?? model.bio;
}
