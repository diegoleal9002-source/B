import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CustomPerson } from "@/lib/roster";

export type ChatMessage = {
  id: string;
  role: "user" | "her";
  text: string;
  at: number;
  image?: string;
  audio?: string;
  video?: string;
  adult?: boolean;
};

type MediaKind = "text" | "photo" | "voice" | "clip";

type DreamState = {
  adultOk: boolean;
  birthDate: string;
  nsfw: boolean;
  blurNsfw: boolean;
  deluxe: boolean;
  coins: number;
  persona: string;
  liked: string[];
  threads: Record<string, ChatMessage[]>;
  typingFor: string | null;
  upgradeOpen: boolean;
  customs: CustomPerson[];
  portraits: Record<string, string>;
  looks: Record<string, string>;
  used: { photo: number; voice: number; clip: number };
  acceptAdult: (birthDate: string) => void;
  setNsfw: (on: boolean) => void;
  setBlurNsfw: (on: boolean) => void;
  setPersona: (name: string) => void;
  toggleLike: (id: string) => void;
  setUpgradeOpen: (open: boolean) => void;
  unlockDeluxe: () => void;
  seedThread: (modelId: string, text: string) => void;
  canSpend: (kind: MediaKind) => "ok" | "nocoins" | "cap";
  pushUser: (modelId: string, text: string, image?: string, audio?: string) => "ok" | "empty" | "nocoins";
  pushHer: (modelId: string, message: Omit<ChatMessage, "id" | "role" | "at">) => void;
  patchLastHer: (modelId: string, patch: Partial<ChatMessage>) => void;
  setTyping: (modelId: string | null) => void;
  resetThread: (modelId: string) => void;
  saveCustom: (person: CustomPerson) => void;
  setPortrait: (id: string, url: string) => void;
  setLook: (id: string, look: string) => void;
};

const COST: Record<MediaKind, number> = { text: 1, photo: 3, voice: 1, clip: 8 };
const CAP: Record<Exclude<MediaKind, "text">, number> = { photo: 8, voice: 12, clip: 2 };

function uid() {
  return crypto.randomUUID();
}

function slim(message: ChatMessage): ChatMessage {
  const next = { ...message };
  delete next.audio;
  if (next.image?.startsWith("data:") && next.image.length > 80_000) delete next.image;
  return next;
}

export const useDream = create<DreamState>()(
  persist(
    (set, get) => ({
      adultOk: false,
      birthDate: "",
      nsfw: false,
      blurNsfw: true,
      deluxe: false,
      coins: 24,
      persona: "",
      liked: [],
      threads: {},
      typingFor: null,
      upgradeOpen: false,
      customs: [],
      portraits: {},
      looks: {},
      used: { photo: 0, voice: 0, clip: 0 },
      acceptAdult: (birthDate) => set({ adultOk: true, birthDate }),
      setNsfw: (on) => set((state) => ({ nsfw: on && state.adultOk && Boolean(state.birthDate) })),
      setBlurNsfw: (on) => set({ blurNsfw: on }),
      setPersona: (name) => set({ persona: name.slice(0, 24) }),
      toggleLike: (id) =>
        set((state) => ({
          liked: state.liked.includes(id)
            ? state.liked.filter((item) => item !== id)
            : [...state.liked, id],
        })),
      setUpgradeOpen: (open) => set({ upgradeOpen: open }),
      unlockDeluxe: () => set({ deluxe: true, upgradeOpen: false, coins: 24 }),
      seedThread: (modelId, text) =>
        set((state) => {
          if ((state.threads[modelId] ?? []).length > 0) return state;
          return {
            threads: {
              ...state.threads,
              [modelId]: [{ id: `seed-${modelId}`, role: "her", text, at: Date.now() }],
            },
          };
        }),
      canSpend: (kind) => {
        const state = get();
        if (kind !== "text" && state.used[kind] >= CAP[kind]) return "cap";
        if (!state.deluxe && state.coins < COST[kind]) {
          set({ upgradeOpen: true });
          return "nocoins";
        }
        return "ok";
      },
      pushUser: (modelId, text, image, audio) => {
        const trimmed = text.trim().slice(0, 500);
        if (!trimmed && !image && !audio) return "empty";
        const state = get();
        if (!state.deluxe && state.coins < 1) {
          set({ upgradeOpen: true });
          return "nocoins";
        }
        const message: ChatMessage = {
          id: uid(),
          role: "user",
          text: trimmed || "Te mando esta foto.",
          at: Date.now(),
          image,
          audio,
        };
        set({
          coins: state.deluxe ? state.coins : state.coins - 1,
          typingFor: modelId,
          threads: {
            ...state.threads,
            [modelId]: [...(state.threads[modelId] ?? []), message],
          },
        });
        return "ok";
      },
      pushHer: (modelId, message) =>
        set((state) => {
          const kind: MediaKind = message.video ? "clip" : message.image ? "photo" : message.audio ? "voice" : "text";
          const cost = COST[kind];
          const used =
            kind === "text"
              ? state.used
              : { ...state.used, [kind]: state.used[kind] + 1 };
          return {
            typingFor: state.typingFor === modelId ? null : state.typingFor,
            coins: state.deluxe ? state.coins : Math.max(0, state.coins - (kind === "text" ? 0 : cost)),
            used,
            threads: {
              ...state.threads,
              [modelId]: [
                ...(state.threads[modelId] ?? []),
                { id: uid(), role: "her", at: Date.now(), ...message },
              ],
            },
          };
        }),
      patchLastHer: (modelId, patch) =>
        set((state) => {
          const thread = state.threads[modelId] ?? [];
          const last = thread[thread.length - 1];
          if (!last || last.role !== "her") return state;
          const next = thread.slice(0, -1);
          next.push({ ...last, ...patch });
          return { threads: { ...state.threads, [modelId]: next } };
        }),
      setTyping: (modelId) => set({ typingFor: modelId }),
      resetThread: (modelId) =>
        set((state) => {
          const threads = { ...state.threads };
          delete threads[modelId];
          return { threads, typingFor: state.typingFor === modelId ? null : state.typingFor };
        }),
      saveCustom: (person) =>
        set((state) => ({
          customs: [person, ...state.customs.filter((item) => item.id !== person.id)],
          portraits: { ...state.portraits, [person.id]: person.image },
        })),
      setPortrait: (id, url) => set((state) => ({ portraits: { ...state.portraits, [id]: url } })),
      setLook: (id, look) => set((state) => ({ looks: { ...state.looks, [id]: look } })),
    }),
    {
      name: "dreamforge-v2",
      partialize: (state) => ({
        adultOk: state.adultOk,
        birthDate: state.birthDate,
        nsfw: state.nsfw,
        blurNsfw: state.blurNsfw,
        deluxe: state.deluxe,
        coins: state.coins,
        persona: state.persona,
        liked: state.liked,
        customs: state.customs,
        portraits: state.portraits,
        looks: state.looks,
        used: state.used,
        threads: Object.fromEntries(
          Object.entries(state.threads).map(([id, messages]) => [id, messages.map(slim)]),
        ),
      }),
    },
  ),
);
