import { CAST, type Model } from "@/data/cast";

export type Style = "realista" | "anime" | "ilustracion";

export type CustomPerson = {
  id: string;
  name: string;
  age: number;
  style: Style;
  appearance: string;
  personality: string;
  place: string;
  voice: string;
  image: string;
  opener: string;
};

export type Person = {
  id: string;
  name: string;
  age: number;
  image: string;
  hook: string;
  bio: string;
  place: string;
  opener: string;
  voice: string;
  appearance: string;
  personality: string;
  style: Style;
  tags: string[];
  chats: number;
  likes: number;
  custom: boolean;
};

export const VOICES = [
  { id: "eve", label: "Eve" },
  { id: "ara", label: "Ara" },
  { id: "luna", label: "Luna" },
  { id: "liora", label: "Liora" },
  { id: "celeste", label: "Celeste" },
  { id: "leo", label: "Leo" },
  { id: "orion", label: "Orion" },
  { id: "rex", label: "Rex" },
] as const;

const PRESET_VOICE: Record<string, string> = {
  camille: "eve",
  iris: "ara",
  noa: "luna",
  vera: "liora",
  lena: "celeste",
  rosa: "aurora",
  mara: "ursa",
  nia: "carina",
};

export function fromCast(model: Model, image?: string, look?: string): Person {
  const appearance =
    look ||
    `${model.name}, ${model.age} años, pelo ${model.hair}, ojos ${model.eyes}. ${model.bio}`;
  return {
    id: model.id,
    name: model.name,
    age: model.age,
    image: image || model.image,
    hook: model.hook,
    bio: model.bio,
    place: model.place,
    opener: model.opener,
    voice: PRESET_VOICE[model.id] ?? "eve",
    appearance,
    personality: `${model.bio} ${model.work}`,
    style: "realista",
    tags: model.tags,
    chats: model.chats,
    likes: model.likes,
    custom: false,
  };
}

export function fromCustom(person: CustomPerson, image?: string, look?: string): Person {
  return {
    id: person.id,
    name: person.name,
    age: person.age,
    image: image || person.image,
    hook: person.place,
    bio: person.personality,
    place: person.place,
    opener: person.opener,
    voice: person.voice,
    appearance: look || person.appearance,
    personality: person.personality,
    style: person.style,
    tags: ["mia"],
    chats: 0,
    likes: 0,
    custom: true,
  };
}

export function resolvePerson(
  id: string,
  customs: CustomPerson[],
  portraits: Record<string, string>,
  looks: Record<string, string>,
): Person | undefined {
  const custom = customs.find((item) => item.id === id);
  if (custom) return fromCustom(custom, portraits[id], looks[id]);
  const preset = CAST.find((item) => item.id === id);
  if (!preset) return undefined;
  return fromCast(preset, portraits[id], looks[id]);
}

export function roster(
  customs: CustomPerson[],
  portraits: Record<string, string>,
  looks: Record<string, string>,
): Person[] {
  return [
    ...customs.map((item) => fromCustom(item, portraits[item.id], looks[item.id])),
    ...CAST.map((item) => fromCast(item, portraits[item.id], looks[item.id])),
  ];
}
