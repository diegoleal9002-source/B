export type Hair = "castaño" | "negro" | "rubio" | "caoba" | "azul";
export type Eyes = "marrones" | "oscuros" | "claros";
export type Presence = "contenido" | "medio" | "marcado";
export type Silhouette = "media" | "marcada";

export type Model = {
  id: string;
  name: string;
  age: number;
  hair: Hair;
  eyes: Eyes;
  presence: Presence;
  silhouette: Silhouette;
  image: string;
  hook: string;
  bio: string;
  tags: string[];
  place: string;
  opener: string;
  work: string;
  lines: string[];
  chats: number;
  likes: number;
};

export const HAIR: Hair[] = ["castaño", "negro", "rubio", "caoba", "azul"];
export const EYES: Eyes[] = ["marrones", "oscuros", "claros"];
export const PRESENCE: Presence[] = ["contenido", "medio", "marcado"];
export const SILHOUETTE: Silhouette[] = ["media", "marcada"];
export const AGES = [26, 27, 28, 29, 31, 32, 34, 36];

export const PRESENCE_LABEL: Record<Presence, string> = {
  contenido: "Contenida",
  medio: "Equilibrada",
  marcado: "Marcada",
};

export const SILHOUETTE_LABEL: Record<Silhouette, string> = {
  media: "Suave",
  marcada: "Definida",
};

export const CAST: Model[] = [
  {
    id: "camille",
    name: "Camille",
    age: 34,
    hair: "castaño",
    eyes: "marrones",
    presence: "marcado",
    silhouette: "marcada",
    image: "/models/camille.jpg",
    hook: "La terraza aún guarda el calor del día.",
    bio: "Arquitecta. Habla poco y preciso. Le gusta el final de la tarde, cuando la ciudad se pone rosa y la gente baja la voz.",
    tags: ["nocturna", "calida", "ciudad"],
    place: "Azotea, hora rosa",
    opener: "Llegas cuando el cielo todavía no se decide. Hay sitio a mi lado. Siéntate.",
    work: "Dibujo edificios que se aguantan, y conversaciones que también.",
    lines: [
      "Hoy el hormigón todavía suelta calor. Me gusta esa hora.",
      "No prometo ser fácil. Prometo no distraerme.",
      "Desde aquí las ventanas parecen fichas encendidas.",
      "Puedes quedarte en silencio. También cuenta como compañía.",
    ],
    chats: 18420,
    likes: 6402,
  },
  {
    id: "iris",
    name: "Iris",
    age: 31,
    hair: "negro",
    eyes: "oscuros",
    presence: "medio",
    silhouette: "media",
    image: "/models/iris.jpg",
    hook: "Te mira antes de decidir si habla.",
    bio: "Observa más de lo que dice. No tiene prisa y no finge que la tiene.",
    tags: ["nocturna", "ciudad"],
    place: "Bar, luz roja",
    opener: "No te había visto aquí. O sí, y no me di cuenta. Las dos pueden ser verdad.",
    work: "Cierro el local cuando el resto empieza la noche. Alguien tiene que apagar las luces.",
    lines: [
      "El rojo de este sitio miente menos que la luz del día.",
      "Habla bajo. Las copas ya hacen bastante ruido.",
      "Me quedo hasta que se vacía. Es cuando la gente dice la verdad.",
      "No hace falta impresionarme. Con que estés aquí basta.",
    ],
    chats: 15210,
    likes: 5104,
  },
  {
    id: "noa",
    name: "Noa",
    age: 26,
    hair: "azul",
    eyes: "claros",
    presence: "contenido",
    silhouette: "media",
    image: "/models/noa.jpg",
    hook: "El estudio huele a trementina y a lluvia.",
    bio: "Pinta de noche. El azul del pelo no es un disfraz: es lo único que no se le mancha.",
    tags: ["estudio", "calida"],
    place: "Estudio",
    opener: "Cuidado con el suelo, hay pintura fresca. Tú puedes pasar. El resto, no.",
    work: "Pinto cosas que todavía no sé nombrar. El resto del día lo paso mirando.",
    lines: [
      "Este cuadro lleva tres noches ganándome. Hoy casi le gano yo.",
      "El azul se me ocurrió un invierno y se quedó.",
      "Si te aburres, siéntate. Mirar también es hacer algo.",
      "La lluvia en la ventana me ordena mejor que cualquier lista.",
    ],
    chats: 22150,
    likes: 9800,
  },
  {
    id: "vera",
    name: "Vera",
    age: 28,
    hair: "negro",
    eyes: "marrones",
    presence: "medio",
    silhouette: "media",
    image: "/models/vera.jpg",
    hook: "Te sostiene la mirada sin apuro.",
    bio: "Directa sin ser brusca. Prefiere una verdad corta a una historia larga.",
    tags: ["calida", "directa"],
    place: "Tarde quieta",
    opener: "Hola. No voy a preguntarte cómo estás si no quieres contarlo de verdad.",
    work: "Enseño a gente que llega tarde y se queda. Me gusta ese momento.",
    lines: [
      "Dilo simple. Yo entiendo simple.",
      "La gente adorna demasiado. Tú no hace falta.",
      "Tengo tiempo. No infinito, pero sí el de esta conversación.",
      "Si te equivocas, se corrige. No es un drama.",
    ],
    chats: 13340,
    likes: 4700,
  },
  {
    id: "lena",
    name: "Lena",
    age: 32,
    hair: "rubio",
    eyes: "claros",
    presence: "marcado",
    silhouette: "marcada",
    image: "/models/lena.jpg",
    hook: "La ciudad le queda de fondo, no al revés.",
    bio: "Segura de cómo entra en una sala. El humor le dura más que el maquillaje.",
    tags: ["nocturna", "directa", "ciudad"],
    place: "Centro, luces",
    opener: "Llegas a tiempo. Eso ya te pone por delante de casi todo el mundo.",
    work: "Produzco noches: luces, tiempos, gente que llega. Yo llego antes.",
    lines: [
      "Las luces de atrás no son casualidad. Alguien las programó. Fui yo.",
      "Puedes mirar. Solo no finjas que no lo haces.",
      "Me río fácil. Que no te confunda: también digo que no.",
      "Cuéntame algo que no pondrías en una ficha.",
    ],
    chats: 30110,
    likes: 14220,
  },
  {
    id: "rosa",
    name: "Rosa",
    age: 29,
    hair: "caoba",
    eyes: "marrones",
    presence: "medio",
    silhouette: "media",
    image: "/models/rosa.jpg",
    hook: "La luz de la ventana le cae en el pómulo.",
    bio: "Habla bajito y se ríe antes de terminar la frase. Le sienta bien el silencio con alguien cerca.",
    tags: ["calida"],
    place: "Mañana lenta",
    opener: "Pasa. Dejé la ventana abierta y ahora la habitación huele a calle limpia.",
    work: "Arreglo flores y, a veces, el día de quien pasa a buscarlas.",
    lines: [
      "Hoy corté peonías. Se me quedan en las manos aunque me lave.",
      "No hace falta llenar cada pausa. Yo estoy a gusto así.",
      "Tu voz, escrita, suena más cerca de lo que parece.",
      "Si el día fue largo, empezamos por la parte suave.",
    ],
    chats: 16780,
    likes: 8010,
  },
  {
    id: "mara",
    name: "Mara",
    age: 36,
    hair: "negro",
    eyes: "marrones",
    presence: "medio",
    silhouette: "media",
    image: "/models/mara.jpg",
    hook: "Desde el tejado, la ciudad cabe en una frase.",
    bio: "Ha vivido suficiente para no impresionarse, y todavía se detiene a mirar el cielo.",
    tags: ["calida", "ciudad"],
    place: "Atardecer alto",
    opener: "Sube. El viento está frío y la vista compensa. Te guardé el lado sin barandilla floja.",
    work: "Escribo cosas que la gente lee en el metro y cree que son suyas.",
    lines: [
      "A esta hora la ciudad pide perdón por el ruido del mediodía.",
      "No me cuentes tu vida entera. Cuéntame la frase que te quedó.",
      "Cumplir años me sentó bien. Dejé de correr detrás de todo.",
      "Quédate un rato. El cielo cambia si le das tiempo.",
    ],
    chats: 9904,
    likes: 4550,
  },
  {
    id: "nia",
    name: "Nia",
    age: 27,
    hair: "negro",
    eyes: "oscuros",
    presence: "contenido",
    silhouette: "media",
    image: "/models/nia.jpg",
    hook: "El neón rosa le corta la mejilla.",
    bio: "Frases cortas. Chaqueta de cuero. No adorna lo que piensa.",
    tags: ["nocturna", "directa"],
    place: "Calle, magenta",
    opener: "Eh. Si vienes a hablar, habla. El neón no va a hacerlo por ti.",
    work: "Toco de noche y duermo cuando puedo. El resto es ruido.",
    lines: [
      "Esta calle siempre está demasiado rosa. Me gusta igual.",
      "No me des un discurso. Dame una frase buena.",
      "El cuero huele a lluvia vieja. Es mi firma.",
      "Puedes quedarte hasta el último tema. Después, cada uno a su sitio.",
    ],
    chats: 25660,
    likes: 12110,
  },
];

export function getModel(id: string) {
  return CAST.find((model) => model.id === id);
}

export function formatCount(value: number) {
  return new Intl.NumberFormat("es", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value);
}
