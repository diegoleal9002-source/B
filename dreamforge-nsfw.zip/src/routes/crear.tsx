import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  AGES,
  EYES,
  HAIR,
  PRESENCE,
  PRESENCE_LABEL,
  SILHOUETTE,
  SILHOUETTE_LABEL,
} from "@/data/cast";
import { makePicture } from "@/lib/dream-ai";
import { adultAge, blockedReason } from "@/lib/guard";
import { cn } from "@/lib/cn";
import { DEFAULT_PICK, likeness, rankModels, type PickTraits } from "@/lib/match";
import { VOICES, type Style } from "@/lib/roster";
import { useDream } from "@/lib/store";

export const Route = createFileRoute("/crear")({
  head: () => ({ meta: [{ title: "Crear · DreamForge" }] }),
  component: CreatePage,
});

const STYLES: { id: Style; label: string; note: string }[] = [
  { id: "realista", label: "Realista", note: "Foto" },
  { id: "anime", label: "Anime", note: "Dibujo" },
  { id: "ilustracion", label: "Ilustración", note: "Pintura" },
];

function CreatePage() {
  const navigate = useNavigate();
  const saveCustom = useDream((s) => s.saveCustom);
  const nsfw = useDream((s) => s.nsfw);
  const [name, setName] = useState("");
  const [age, setAge] = useState(27);
  const [style, setStyle] = useState<Style>("realista");
  const [appearance, setAppearance] = useState("");
  const [personality, setPersonality] = useState("");
  const [place, setPlace] = useState("");
  const [voice, setVoice] = useState("eve");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [preview, setPreview] = useState("");

  async function generate() {
    const cleanName = name.trim().slice(0, 32);
    const look = appearance.trim();
    // The profile portrait is always SFW (it shows in Explorar); +18 only affects the
    // personality and what happens in the chat.
    const reason =
      blockedReason(`${cleanName} ${look} ${place}`) || blockedReason(personality, nsfw);
    if (!cleanName || look.length < 8) {
      setError("Pon un nombre y describe el aspecto con un poco más de detalle.");
      return;
    }
    if (!adultAge(age)) {
      setError("La edad tiene que estar entre 18 y 80.");
      return;
    }
    if (reason) {
      setError(reason);
      return;
    }
    setBusy(true);
    setError("");
    const result = await makePicture({
      data: {
        name: cleanName,
        age,
        style,
        appearance: look,
        scene: place.trim() || "retrato de frente, luz suave",
      },
    });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    const id = `u-${crypto.randomUUID().slice(0, 8)}`;
    saveCustom({
      id,
      name: cleanName,
      age,
      style,
      appearance: look,
      personality: personality.trim() || "Cercana, con humor y sin rodeos.",
      place: place.trim() || "Aquí",
      voice,
      image: result.url,
      opener: `Hola. Soy ${cleanName}. ${personality.trim() || "Cuéntame qué te trae."}`,
    });
    setPreview(result.url);
    await navigate({ to: "/c/$id", params: { id } });
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto grid max-w-6xl gap-6 px-3 py-4 sm:px-5 lg:grid-cols-[1fr_320px]">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">Crear desde cero</h1>
          <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted">
            No estás atado a las fichas de la casa. Describes a la persona y la IA genera el retrato. En el
            chat puede cambiar de aspecto si se lo pides.
          </p>

          <label className="mt-5 block text-xs font-semibold tracking-wide text-muted uppercase">
            Nombre
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="mt-2 h-11 w-full rounded-2xl border border-line bg-surface px-4 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
              placeholder="Cómo se llama"
            />
          </label>

          <label className="mt-4 block text-xs font-semibold tracking-wide text-muted uppercase">
            Edad
            <input
              type="number"
              min={18}
              max={80}
              value={age}
              onChange={(event) => setAge(Number(event.target.value))}
              className="mt-2 h-11 w-28 rounded-2xl border border-line bg-surface px-4 text-sm font-normal text-fg outline-none focus-visible:outline-2 focus-visible:outline-pink"
            />
          </label>

          <fieldset className="mt-4">
            <legend className="text-xs font-semibold tracking-wide text-muted uppercase">Estilo</legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {STYLES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={style === item.id}
                  onClick={() => setStyle(item.id)}
                  className={cn(
                    "h-10 rounded-full px-4 text-sm",
                    style === item.id ? "bg-pink font-semibold text-fg" : "bg-surface-2 text-muted",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </fieldset>

          <label className="mt-4 block text-xs font-semibold tracking-wide text-muted uppercase">
            Aspecto
            <textarea
              value={appearance}
              onChange={(event) => setAppearance(event.target.value)}
              rows={3}
              placeholder="Pelo, ropa, cara, energía. Siempre adulto. (El retrato de perfil es vestido; lo +18 va en el chat.)"
              className="mt-2 w-full resize-none rounded-2xl border border-line bg-surface px-4 py-3 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
            />
          </label>

          <label className="mt-4 block text-xs font-semibold tracking-wide text-muted uppercase">
            Personalidad
            <textarea
              value={personality}
              onChange={(event) => setPersonality(event.target.value)}
              rows={2}
              placeholder="Cómo habla y qué le importa"
              className="mt-2 w-full resize-none rounded-2xl border border-line bg-surface px-4 py-3 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
            />
          </label>

          <label className="mt-4 block text-xs font-semibold tracking-wide text-muted uppercase">
            Dónde está
            <input
              value={place}
              onChange={(event) => setPlace(event.target.value)}
              className="mt-2 h-11 w-full rounded-2xl border border-line bg-surface px-4 text-sm font-normal tracking-normal text-fg normal-case outline-none focus-visible:outline-2 focus-visible:outline-pink"
              placeholder="Un café, un estudio, la calle de noche"
            />
          </label>

          <fieldset className="mt-4">
            <legend className="text-xs font-semibold tracking-wide text-muted uppercase">Voz</legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {VOICES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={voice === item.id}
                  onClick={() => setVoice(item.id)}
                  className={cn(
                    "h-10 rounded-full px-4 text-sm",
                    voice === item.id ? "bg-pink font-semibold text-fg" : "bg-surface-2 text-muted",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </fieldset>

          {error && <p className="mt-4 text-sm text-pink">{error}</p>}
          <button
            type="button"
            disabled={busy}
            onClick={() => void generate()}
            className="mt-5 h-12 w-full rounded-full bg-pink text-sm font-semibold text-fg disabled:opacity-40 sm:w-auto sm:px-8"
          >
            {busy ? "Generando retrato…" : "Generar y empezar a hablar"}
          </button>
        </div>

        <aside className="overflow-hidden rounded-3xl border border-line bg-surface lg:sticky lg:top-4 lg:self-start">
          {preview ? (
            <img src={preview} alt="" className="aspect-3/4 w-full object-cover" />
          ) : (
            <div className="grid aspect-3/4 place-items-center px-6 text-center text-sm text-muted">
              El retrato aparece aquí cuando la IA lo termina.
            </div>
          )}
        </aside>
      </div>
      <Matcher />
    </div>
  );
}

function Matcher() {
  const [open, setOpen] = useState(false);
  const [pick, setPick] = useState<PickTraits>(DEFAULT_PICK);
  const ranked = useMemo(() => rankModels(pick), [pick]);
  const best = ranked[0];
  const match = best ? likeness(best, pick) : null;
  if (!open) {
    return (
      <div className="mx-auto max-w-6xl px-3 pb-8 sm:px-5">
        <button type="button" onClick={() => setOpen(true)} className="text-sm text-muted underline">
          O acercar una ficha que ya existe
        </button>
      </div>
    );
  }
  return (
    <div className="mx-auto max-w-6xl px-3 pb-10 sm:px-5">
      <h2 className="text-lg font-semibold">Fichas de la casa</h2>
      <Trait label="Pelo" options={HAIR} value={pick.hair} onChange={(hair) => setPick((c) => ({ ...c, hair }))} render={capitalize} />
      <Trait label="Ojos" options={EYES} value={pick.eyes} onChange={(eyes) => setPick((c) => ({ ...c, eyes }))} render={capitalize} />
      <Trait
        label="Presencia"
        options={PRESENCE}
        value={pick.presence}
        onChange={(presence) => setPick((c) => ({ ...c, presence }))}
        render={(value) => PRESENCE_LABEL[value]}
      />
      <Trait
        label="Silueta"
        options={SILHOUETTE}
        value={pick.silhouette}
        onChange={(silhouette) => setPick((c) => ({ ...c, silhouette }))}
        render={(value) => SILHOUETTE_LABEL[value]}
      />
      <Trait label="Edad" options={AGES} value={pick.age} onChange={(age) => setPick((c) => ({ ...c, age }))} render={(value) => String(value)} />
      {best && match && (
        <Link to="/c/$id" params={{ id: best.id }} className="mt-4 flex items-center gap-3 rounded-2xl border border-line bg-surface p-3">
          <img src={best.image} alt="" className="size-16 rounded-xl object-cover" />
          <span>
            <span className="block font-semibold">
              {best.name}, {best.age}
            </span>
            <span className="text-sm text-muted">
              {match.score} de {match.max}
              {match.hits.length ? ` · ${match.hits.join(", ")}` : ""}
            </span>
          </span>
        </Link>
      )}
    </div>
  );
}

function Trait<T extends string | number>({
  label,
  options,
  value,
  onChange,
  render,
}: {
  label: string;
  options: readonly T[];
  value: T;
  onChange: (value: T) => void;
  render: (value: T) => string;
}) {
  return (
    <fieldset className="mt-4">
      <legend className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</legend>
      <div className="mt-2 flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            key={String(option)}
            type="button"
            aria-pressed={option === value}
            onClick={() => onChange(option)}
            className={cn(
              "h-10 rounded-full px-4 text-sm",
              option === value ? "bg-pink font-semibold text-fg" : "bg-surface-2 text-muted",
            )}
          >
            {render(option)}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function capitalize(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}
