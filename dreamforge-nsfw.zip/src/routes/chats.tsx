import { createFileRoute, Link } from "@tanstack/react-router";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { roster } from "@/lib/roster";
import { useDream } from "@/lib/store";

export const Route = createFileRoute("/chats")({
  head: () => ({ meta: [{ title: "Chats · DreamForge" }] }),
  component: ChatsPage,
});

function ChatsPage() {
  const threads = useDream((s) => s.threads);
  const customs = useDream((s) => s.customs);
  const portraits = useDream((s) => s.portraits);
  const looks = useDream((s) => s.looks);
  const resetThread = useDream((s) => s.resetThread);
  const people = roster(customs, portraits, looks);

  const rows = Object.entries(threads)
    .map(([id, messages]) => {
      const model = people.find((item) => item.id === id);
      const last = messages[messages.length - 1];
      if (!model || !last) return null;
      return { model, last, count: messages.length };
    })
    .filter((row) => row !== null)
    .sort((a, b) => b.last.at - a.last.at);

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-2xl px-3 py-4 sm:px-5">
        <h1 className="text-2xl font-extrabold tracking-tight">Chats</h1>
        <p className="mt-1 text-sm text-muted">Las conversaciones se quedan en este navegador.</p>

        {rows.length === 0 ? (
          <div className="mt-8 rounded-3xl border border-line bg-surface p-6">
            <p className="text-sm text-muted">Todavía no hablaste con nadie.</p>
            <div className="mt-4 grid grid-cols-4 gap-2">
              {people.slice(0, 4).map((model) => (
                <Link key={model.id} to="/c/$id" params={{ id: model.id }}>
                  <img
                    src={model.image}
                    alt={model.name}
                    className="aspect-3/4 w-full rounded-xl object-cover"
                  />
                  <p className="mt-1 truncate text-xs">{model.name}</p>
                </Link>
              ))}
            </div>
            <Link
              to="/"
              className="mt-5 flex h-11 items-center justify-center rounded-full bg-pink text-sm font-semibold text-fg"
            >
              Explorar fichas
            </Link>
          </div>
        ) : (
          <ul className="mt-4 divide-y divide-line overflow-hidden rounded-3xl border border-line bg-surface">
            {rows.map(({ model, last }) => (
              <li key={model.id} className="flex items-center gap-3 px-3 py-3">
                <Link to="/c/$id" params={{ id: model.id }} className="flex min-w-0 flex-1 items-center gap-3">
                  <img src={model.image} alt="" className="size-14 shrink-0 rounded-2xl object-cover" />
                  <span className="min-w-0">
                    <span className="block font-semibold">
                      {model.name} <span className="font-normal text-muted">{model.age}</span>
                    </span>
                    <span className="mt-0.5 block truncate text-sm text-muted">{last.text}</span>
                    <span className="mt-0.5 block text-xs text-muted">
                      {formatDistanceToNow(last.at, { addSuffix: true, locale: es })}
                    </span>
                  </span>
                </Link>
                <button
                  type="button"
                  onClick={() => resetThread(model.id)}
                  className="shrink-0 rounded-full px-3 py-2 text-xs text-muted hover:text-fg"
                >
                  Borrar
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
