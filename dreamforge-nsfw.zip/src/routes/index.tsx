import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { PortraitCard } from "@/components/portrait-card";
import { cn } from "@/lib/cn";
import { roster } from "@/lib/roster";
import { useDream } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Explorar · DreamForge" }] }),
  component: Explore,
});

const CHIPS = [
  { id: "todas", label: "Todas" },
  { id: "tendencia", label: "Tendencia" },
  { id: "mias", label: "Mías" },
  { id: "nocturna", label: "Nocturnas" },
  { id: "calida", label: "Cálidas" },
  { id: "directa", label: "Directas" },
  { id: "ciudad", label: "Ciudad" },
  { id: "estudio", label: "Estudio" },
  { id: "guardadas", label: "Guardadas" },
] as const;

type ChipId = (typeof CHIPS)[number]["id"];

const BADGE = {
  realista: "Realista",
  anime: "Anime",
  ilustracion: "Dibujo",
} as const;

function Explore() {
  const [query, setQuery] = useState("");
  const [chip, setChip] = useState<ChipId>("tendencia");
  const liked = useDream((s) => s.liked);
  const customs = useDream((s) => s.customs);
  const portraits = useDream((s) => s.portraits);
  const looks = useDream((s) => s.looks);
  const setUpgradeOpen = useDream((s) => s.setUpgradeOpen);
  const deluxe = useDream((s) => s.deluxe);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    let rows = roster(customs, portraits, looks).filter((model) => {
      if (chip === "guardadas" && !liked.includes(model.id)) return false;
      if (chip === "mias" && !model.custom) return false;
      if (
        chip !== "todas" &&
        chip !== "tendencia" &&
        chip !== "guardadas" &&
        chip !== "mias" &&
        !model.tags.includes(chip)
      ) {
        return false;
      }
      if (!q) return true;
      const blob = `${model.name} ${model.hook} ${model.place} ${model.appearance} ${model.tags.join(" ")}`.toLowerCase();
      return blob.includes(q);
    });
    if (chip === "tendencia") {
      rows = [...rows].sort((a, b) => Number(b.custom) - Number(a.custom) || b.chats - a.chats);
    }
    return rows;
  }, [chip, customs, liked, looks, portraits, query]);

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-6xl px-3 py-4 sm:px-5">
        {!deluxe && (
          <button
            type="button"
            onClick={() => setUpgradeOpen(true)}
            className="mb-4 flex w-full items-center justify-between gap-3 rounded-2xl border border-line bg-surface px-4 py-3 text-left"
          >
            <span>
              <span className="block text-sm font-semibold">Chat sin límite de fichas</span>
              <span className="mt-0.5 block text-xs text-muted">Fotos, voz y vídeo siguen teniendo un tope.</span>
            </span>
            <span className="shrink-0 rounded-full bg-pink px-3 py-1.5 text-xs font-semibold text-fg">Ver</span>
          </button>
        )}

        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight">Explorar</h1>
            <p className="mt-1 text-sm text-muted">{list.length} fichas · las tuyas y las de la casa</p>
          </div>
          <label className="relative block sm:w-72">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Nombre o lugar"
              className="h-11 w-full rounded-full border border-line bg-surface pr-4 pl-10 text-sm outline-none focus-visible:outline-2 focus-visible:outline-pink"
            />
          </label>
        </div>

        <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1">
          {CHIPS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setChip(item.id)}
              className={cn(
                "h-10 shrink-0 rounded-full px-4 text-sm font-medium",
                chip === item.id ? "bg-pink text-fg" : "bg-surface-2 text-muted",
              )}
            >
              {item.label}
            </button>
          ))}
        </div>

        {list.length === 0 ? (
          <p className="mt-10 text-sm text-muted">
            {chip === "guardadas"
              ? "Todavía no guardaste ninguna ficha."
              : chip === "mias"
                ? "Aún no creaste ninguna. En Crear puedes inventar una desde cero."
                : "Nada coincide con esa búsqueda."}
          </p>
        ) : (
          <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
            {list.map((model) => (
              <PortraitCard
                key={model.id}
                model={{
                  id: model.id,
                  name: model.name,
                  age: model.age,
                  image: model.image,
                  hook: model.hook,
                  chats: model.chats,
                  likes: model.likes,
                  badge: model.custom ? "Tuya" : BADGE[model.style],
                }}
              />
            ))}
          </div>
        )}

        <p className="mt-8 pb-6 text-xs leading-relaxed text-muted">
          La IA adapta cada ficha en el chat y puede mandar foto, voz o vídeo. Sin contenido sexual.
        </p>
      </div>
    </div>
  );
}
